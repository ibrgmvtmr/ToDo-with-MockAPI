 package kg.interns.model;
 import javax.swing.text.Document;



 public class Service {


   public boolean sendDocument( Document contentDocument) {
       ClientForBackendServer client = new ClientForBackendServer("157.230.30.221", 4042);
       //ClientForBackendServer client = new ClientForBackendServer("127.0.0.1", 4042);

       if(client.getStateSocket()){
           return client.sendDocument(contentDocument);
       }
        return false;
   }

 }
