package kg.interns.model;

import kg.interns.viewer.Viewer;


import javax.swing.JSpinner;
import javax.swing.JDialog;
import javax.swing.JRootPane;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SpaceManager implements ActionListener {
    private Viewer viewer;
    private int currentSpaceValue;

    public SpaceManager(Viewer viewer) {
        this.viewer = viewer;
        JDialog spaceDialog = (JDialog) viewer.getFontDialog();
        JRootPane rootPane = (JRootPane) spaceDialog.getComponent(0);
        JLayeredPane  layeredPane  = (JLayeredPane) rootPane.getComponent(1);
        JPanel  panel  = (JPanel) layeredPane.getComponent(0);
        JPanel  panel1  = (JPanel) panel.getComponent(0);
        JSpinner  spinner  = (JSpinner) panel1.getComponent(0);
        this.currentSpaceValue = (int) spinner.getValue();
    }

    public int getCurrentSpaceValue(){
      JDialog spaceDialog = (JDialog) viewer.getFontDialog();
      JRootPane rootPane = (JRootPane) spaceDialog.getComponent(0);
      JLayeredPane  layeredPane  = (JLayeredPane) rootPane.getComponent(1);
      JPanel  panel  = (JPanel) layeredPane.getComponent(0);
      JPanel  panel1  = (JPanel) panel.getComponent(0);
      JSpinner  spinner  = (JSpinner) panel1.getComponent(0);
      currentSpaceValue = (int) spinner.getValue();
      return currentSpaceValue;
    }



    public void updateWordSpace(int currentSpaceValue) {
        String text = viewer.getCurrentContent().getText();
        String newtext = "";
        int newWord = 0;
        if (currentSpaceValue > 0) {
            for (int i = 0; i < text.length(); i++) {
                if (text.charAt(i) != ' ') {
                    newtext = newtext + text.charAt(i);
                    newWord = 0;
                } else if (newWord != 1) {
                    int temp = currentSpaceValue;
                    while (temp>0) {
                        newtext = newtext + " ";
                        temp = temp - 1;
                    }
                    newWord = 1;
                }
            }
            viewer.updateOpen(newtext);
        }

    }


    @Override
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();
        currentSpaceValue = getCurrentSpaceValue();
        if ("ApplySpace".equals(command)) {
            updateWordSpace(currentSpaceValue);
        }
    }

}
