package viewer;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.border.BevelBorder;
import java.awt.Font;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Dimension;

public class StatusBarPanel {
    private JPanel statusPanel;
    private JLabel labelOfColumn;
    private JLabel labelOfLines;

    public StatusBarPanel() {
        Font fontForLabels = new Font("Arial", Font.BOLD, 13);

        // Label of column in line
        labelOfColumn = new JLabel("Column: 1,");
        labelOfColumn.setFont(fontForLabels);

        // Label of lines in text
        labelOfLines = new JLabel("Lines: 1 ");
        labelOfLines.setFont(fontForLabels);

        // Label of UTF-8
        JLabel labelUTF = new JLabel(" UTF-8");
        labelUTF.setFont(fontForLabels);

        // Label separator
        JLabel labelSeparator = new JLabel("|");
        labelSeparator.setFont(fontForLabels);

        // Status Bar panel
        statusPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        // Border of panel
        statusPanel.setBackground(new Color(224, 221, 221));
        statusPanel.setBorder(new BevelBorder(BevelBorder.LOWERED));
        statusPanel.setPreferredSize(new Dimension(600, 23));
        // Adding labels
        statusPanel.add(labelOfColumn);
        statusPanel.add(labelOfLines);
        statusPanel.add(labelSeparator);
        statusPanel.add(labelUTF);
        statusPanel.setOpaque(true);
        statusPanel.setVisible(false);
    }

    // Get status bar panel
    public JPanel getStatusPanel() {
        return statusPanel;
    }

    // Set visible status bar panel
    public void setVisiblePanel(boolean isPressed) {
        statusPanel.setVisible(isPressed);
    }

    // Changing values of column and lines
    public void setAmountOfSymbols(int column, int lines) {
        labelOfColumn.setText("Column: " + column + ",");
        labelOfLines.setText("Lines: " + lines + " ");

    }
}
