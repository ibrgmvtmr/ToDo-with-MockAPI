package kg.interns.model;

import kg.interns.viewer.Viewer;
import kg.interns.controller.ActionController;


public class ShowFrameAbout implements ActionController {

    private Viewer viewer;
    private String checker;

    public ShowFrameAbout(Viewer viewer, String checker) {
        this.viewer = viewer;
        this.checker = checker;
    }

    public void doAction() {
        if (checker.equals("About")) {
            viewer.frameAbout(true);
        } else {
            viewer.frameAbout(false);
        }

    }
}
