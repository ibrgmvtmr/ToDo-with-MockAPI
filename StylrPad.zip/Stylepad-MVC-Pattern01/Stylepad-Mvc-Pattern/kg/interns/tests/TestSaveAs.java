package kg.interns.tests;

import kg.interns.viewer.Viewer;
import kg.interns.model.SaveAsDocument;

import javax.swing.text.Document;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.BadLocationException;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

public class TestSaveAs {

  public TestSaveAs() {
    SaveAsDocument saveAsDocument = new SaveAsDocument(null);

    File tempFile = null;
    FileInputStream fileInputStream = null;
    ObjectInputStream objectInputStream = null;

    DefaultStyledDocument documentToSave = new DefaultStyledDocument();
    String dataToSave = "Here is the text for check saving";
    try {
      documentToSave.insertString(0, dataToSave, null);
    } catch (BadLocationException ble) {
      System.out.println("BadLocationException : " + ble);
    }

    try {

      tempFile = File.createTempFile("testSave", ".txt");

      saveAsDocument.saveToFile(tempFile, documentToSave);

      fileInputStream = new FileInputStream(tempFile);
      objectInputStream = new ObjectInputStream(fileInputStream);

      Document dataFromSavedDocument = (Document) objectInputStream.readObject();
      String contentFromFile = dataFromSavedDocument.getText(0, dataFromSavedDocument.getLength());

      if (contentFromFile.equals(dataToSave)) {
        System.out.println("Test Sava As: Success!");
      } else {
        System.out.println("Test Sava As: FAIL!");
      }

    } catch (BadLocationException ble) {
      System.out.println("BadLocationException : " + ble);
    } catch (FileNotFoundException fne) {
      System.out.println("FileNotFoundException : " + fne);
    } catch (ClassNotFoundException cne) {
      System.out.println("ClassNotFoundException : " + cne);
    } catch (IOException ioe) {
      System.out.println("IOException : " + ioe);
    } finally {
      try {
        if (fileInputStream != null) {
          fileInputStream.close();
        }
        if (objectInputStream != null) {
          objectInputStream.close();
        }
        if (tempFile != null) {
          tempFile.delete();
        }
      } catch (IOException ioe) {
        System.out.println("IOException " + ioe);
      }
    }
  }
}
