package kg.interns.model;

import kg.interns.viewer.Viewer;
import kg.interns.controller.ActionController;

public class EditService implements ActionController{
    private Viewer viewer;
    private String command;

    public EditService(Viewer viewer, String command) {
        this.viewer = viewer;
        this.command = command;
    }

    public void doAction() {
      if (command.equals("Find")) {
        viewer.showFindDialog();
      } else if (command.equals("Cancel_Find")) {
        viewer.resetSearch();
      } else if (command.equals("FindButton")) {
        viewer.findText();
      } else if(command.equals("Marker all")){
          viewer.markerAll();
      } else if (command.equals("Cut")) {
        viewer.cut();
      } else if (command.equals("Copy")) {
        viewer.copy();
      } else if (command.equals("Paste")) {
        viewer.paste();
      } else if (command.equals("Replace")){
          viewer.replace();
      } else if (command.equals("ReplaceFunc")){
        // viewer.replaceFunc();
      } else if (command.equals("CloseReplace")){
          viewer.closeDialog();
      } else if (command.equals("CloseDialog")){
          viewer.closeDialog();
      } else if(command.equals("Time_and_date")){
          viewer.insertCurrentDateTime();
      } else if(command.equals("Clear")){
        viewer.clearTextArea();
      } else if(command.equals("Findmore")){
        viewer.showFindMoreDialog();
      } else if(command.equals("FindMoreButton")){
        viewer.findMore();
      } else if(command.equals("CancelFindMore")) {
          viewer.removeHighlightAll();
      } else if (command.equals("GoTo")) {
          viewer.showGoToDialog();
      } else if (command.equals("GoToButton")) {
          viewer.goToLine();
      } else if (command.equals("CancelGoTo")) {
          viewer.closeGoToDialog();
      } else if (command.equals("Font")) {
          viewer.showFontDialog();
      } else if (command.equals("Word Space")) {
          viewer.showSpacetDialog();
        }
    }
}
