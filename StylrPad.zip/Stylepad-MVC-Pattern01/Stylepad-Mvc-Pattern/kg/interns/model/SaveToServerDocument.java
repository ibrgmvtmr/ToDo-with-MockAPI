package kg.interns.model;

import kg.interns.viewer.Viewer;
import javax.swing.text.Document;
import kg.interns.controller.ActionController;


public class SaveToServerDocument implements ActionController {

  private Viewer viewer;
  private Service service;


  public SaveToServerDocument (Viewer viewer) {
    this.viewer = viewer;
  }



  public void doAction() {
    Document contentDocument = viewer.getDocument();


    if(contentDocument != null) {
      service = new Service();
      boolean result = service.sendDocument(contentDocument);
      viewer.showResultSaveDocumentIntoModel(result);
    }

  }

}
