package viewer;

import controller.ActionController;

public class StatusSpace implements ActionController {

    private Viewer viewer;
    private boolean isPressed;

    public StatusSpace(Viewer viewer) {
        this.viewer = viewer;
    }

    @Override
    public void doAction() {
        isPressed = !isPressed;
        viewer.showStatusSpace(isPressed);
    }
}
