package kg.interns.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Component;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

import kg.interns.viewer.Viewer;
import kg.interns.model.PrintDocument;
import kg.interns.model.OpenDocument;
import kg.interns.model.SaveAsDocument;
import kg.interns.model.EditService;
import kg.interns.model.StatusSpace;
import kg.interns.model.ViewService;
import kg.interns.model.ShowFrameAbout;
import kg.interns.model.NewFile;
import kg.interns.model.ExitButton;
import kg.interns.model.SaveDocument;
import kg.interns.model.SaveToServerDocument;

public class Controller extends Component implements ActionListener {

    private Viewer viewer;
    private Map<String, ActionController> map;

    public Controller(Viewer viewer) {
        this.viewer = viewer;
        initializeMap();
    }

    public void actionPerformed(ActionEvent event) {
        String actionCommand = event.getActionCommand();
        doAction(actionCommand);
        System.out.println(actionCommand);
    }

    public void doAction(String command) {
        if (map.containsKey(command)) {
            map.get(command).doAction();
        }
    }

    public void initializeMap() {
        if (map == null) {
            map = new HashMap<>();
        }

        initializeMap("Print", new PrintDocument(viewer));
        initializeMap("Open file", new OpenDocument(viewer));
        initializeMap("Save as", new SaveAsDocument(viewer));
        initializeMap("Save", new SaveDocument(viewer));
        initializeMap("Save to Server", new SaveToServerDocument(viewer));
        initializeMap("New file", new NewFile(viewer));
        initializeMap("Exit", new ExitButton(viewer));
        initializeMap("OpenImage", new ViewService(viewer, "OpenImage"));

        initializeMap("Cut", new EditService(viewer, "Cut"));
        initializeMap("Copy", new EditService(viewer, "Copy"));
        initializeMap("Paste", new EditService(viewer, "Paste"));
        initializeMap("Find", new EditService(viewer, "Find"));
        initializeMap("FindButton", new EditService(viewer, "FindButton"));
        initializeMap("Cancel_Find", new EditService(viewer, "Cancel_Find"));
        initializeMap("Replace", new EditService(viewer, "Replace"));
        initializeMap("ReplaceFunc", new EditService(viewer, "ReplaceFunc"));
        initializeMap("Go", new EditService(viewer, "GoTo"));
        initializeMap("GoToButton", new EditService(viewer, "GoToButton"));
        initializeMap("CancelGoTo", new EditService(viewer, "CancelGoTo"));
        initializeMap("Marker all", new EditService(viewer,"Marker all"));
        initializeMap("Time_and_date", new EditService(viewer, "Time_and_date"));
        initializeMap("Clear", new EditService(viewer, "Clear"));
        initializeMap("Findmore", new EditService(viewer, "Findmore"));
        initializeMap("FindMoreButton", new EditService(viewer, "FindMoreButton"));
        initializeMap("CancelFindMore", new EditService(viewer, "CancelFindMore"));

        initializeMap("Font", new EditService(viewer, "Font"));
        initializeMap("CloseDialog", new EditService(viewer, "CloseDialog"));
        initializeMap("Word Space", new EditService(viewer, "Word Space"));

        initializeMap("Status_space", new StatusSpace(viewer));
        initializeMap("ScaleIn", new ViewService(viewer, "ScaleIn"));
        initializeMap("ScaleOut", new ViewService(viewer, "ScaleOut"));
        initializeMap("DefaultScale", new ViewService(viewer, "DefaultScale"));

        initializeMap("About", new ShowFrameAbout(viewer, "About"));
        initializeMap("OK", new ShowFrameAbout(viewer, "OK"));


    }

    public boolean initializeMap(String command, ActionController actionController) {
        if (map != null) {
            map.put(command, actionController);
            return true;
        }
        return false;
    }
}
