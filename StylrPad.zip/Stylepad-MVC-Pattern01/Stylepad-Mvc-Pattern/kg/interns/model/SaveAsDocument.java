package kg.interns.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import javax.swing.text.Document;

import kg.interns.viewer.Viewer;
import kg.interns.controller.ActionController;


public class SaveAsDocument implements ActionController {

  private Viewer viewer;
  private FileService fileService;

  public SaveAsDocument(Viewer viewer) {
      this.viewer = viewer;
      fileService = FileService.getInstance();


  }




  public void doAction() {

    File file = viewer.showSaveFileDialog();
    if(file != null) {
      Document contentDocument = viewer.getDocument();
      if(contentDocument != null) {
        boolean result = saveToFile(file, contentDocument);
        viewer.showResultSaveDocumentIntoModel(result);
      }
    }
  }


  public boolean saveToFile(File file, Document content) {

        FileOutputStream fileOutputStream = null;
        ObjectOutputStream objectOutputStream = null;

        try {
          fileOutputStream = new FileOutputStream(file);
          objectOutputStream = new ObjectOutputStream(fileOutputStream);
          objectOutputStream.writeObject(content);
          objectOutputStream.flush();
          fileService.setCurrentFile(file);

          return true;
        } catch (NotSerializableException nse) {
          System.out.println("nse" + nse);
        } catch (IOException ioe) {
          System.out.println("ioe" + ioe);
        } finally {
          try {
            if(fileOutputStream != null) {
              fileOutputStream.close();
            }
            if(objectOutputStream != null) {
              objectOutputStream.close();
            }
          } catch (IOException ioe) {
            System.out.println("ioe" + ioe);
          }
        }
        return false;
  }
}
