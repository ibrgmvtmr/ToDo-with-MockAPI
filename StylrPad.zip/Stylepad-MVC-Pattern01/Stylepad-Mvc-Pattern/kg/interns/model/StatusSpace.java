package kg.interns.model;

import kg.interns.viewer.Viewer;
import kg.interns.controller.ActionController;


public class StatusSpace implements ActionController {

    private Viewer viewer;
    private boolean isPressed;

    public StatusSpace(Viewer viewer) {
        this.viewer = viewer;
    }

    public void doAction() {
        isPressed = !isPressed;
        viewer.showStatusSpace(isPressed);
    }
}
