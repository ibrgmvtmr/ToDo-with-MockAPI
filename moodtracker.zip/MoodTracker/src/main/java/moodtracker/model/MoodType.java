package moodtracker.model;

public enum MoodType {
    HAPPY,
    SAD,
    STRESSED,
    TIRED,
    NEUTRAL,
}
