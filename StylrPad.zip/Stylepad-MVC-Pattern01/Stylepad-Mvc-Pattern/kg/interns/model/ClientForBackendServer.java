package kg.interns.model;

import javax.swing.text.Document;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;



public class ClientForBackendServer {


  private Socket socket;
  private boolean stateSocket;

    public ClientForBackendServer(String host, int port) {
        try {
            socket = new Socket(host, port);
            stateSocket = true;
        } catch (UnknownHostException uhe) {
            System.out.println("Error " + uhe);
        } catch (IOException ioe) {
            System.out.println("Error " + ioe);
        }
    }
    public boolean getStateSocket() {
        return  stateSocket;
    }

    public boolean sendDocument(Document contentDocument) {
        return  sendMessage(contentDocument);
    }

    public boolean sendMessage(Document contentDocument) {
        try {
            OutputStream outputStream = socket.getOutputStream();
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(contentDocument);
            objectOutputStream.flush();
        } catch (java.io.IOException ioe) {
            System.out.println(ioe);
            return false;
        }
        return true;
    }
}
