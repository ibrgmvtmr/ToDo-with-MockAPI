package kg.interns.model;

import java.io.File;
import javax.swing.text.Document;
import javax.swing.JOptionPane;
import javax.swing.text.BadLocationException;

import kg.interns.controller.ActionController;
import kg.interns.viewer.Viewer;

public class ExitButton implements ActionController {
    private Viewer viewer;
    private FileService fileService;
    private OpenDocument openDocument;
    private SaveAsDocument saveAsDocument;

    public ExitButton(Viewer viewer) {
      this.viewer = viewer;
      fileService = FileService.getInstance();
    }

    public void doAction() {

      File currentFile = fileService.getCurrentFile();
      Document currentDocument = viewer.getDocument();
      String contentInCurrentFile = viewer.getContent();

      if (currentFile != null) {
          openDocument = new OpenDocument(viewer);
          Document documentFromFile = openDocument.openDocument(currentFile);
          if(!areDocumentsEqual(currentDocument, documentFromFile)) {
            if(viewer.suggestUserToSaveFile()) {
              saveAsDocument = new SaveAsDocument(viewer);
              saveAsDocument.saveToFile(currentFile, currentDocument);
            }
          }
      } else if(!contentInCurrentFile.isEmpty() && viewer.suggestUserToSaveFile()) {
          viewer.clickSaveAs();
      }
      System.exit(0);
    }


    private boolean areDocumentsEqual(Document currentDocument, Document documentFromFile){
        try {
          String text1 = currentDocument.getText(0, currentDocument.getLength());
          String text2 = documentFromFile.getText(0, documentFromFile.getLength());
          return text1.equals(text2);
        } catch (BadLocationException ble) {
          System.out.println("Documents are not equal = " + ble);
          return false;
        }
    }

    private boolean showExitConfirmationDialog() {
        int result = JOptionPane.showConfirmDialog(
            null,
            "Are you sure you want to exit?",
            "Dialog",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );
        return result == JOptionPane.YES_OPTION;
    }
}
