package kg.interns.model;

import java.io.File;

public class FileService {
    private static FileService instanceOf;
    private File currentFile;

    private FileService() {

    }

    public static FileService getInstance() {
        if (instanceOf == null) {
            instanceOf = new FileService();
        }
        return instanceOf;
    }

    public File getCurrentFile() {
        return currentFile;
    }

    public void setCurrentFile(File file) {
        this.currentFile = file;
    }
}
