package controller;

import javax.swing.*;

public class ExitButton implements ActionController {
    @Override
    public void doAction() {
        
        if (showExitConfirmationDialog()) {
            System.exit(0); // Close the application if confirmed
        }
    }

    
    private boolean showExitConfirmationDialog() {
        int result = JOptionPane.showConfirmDialog(
            null,
            "Are you sure you want to exit?",
            "Dialog",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        
        return result == JOptionPane.YES_OPTION;
    }
}
