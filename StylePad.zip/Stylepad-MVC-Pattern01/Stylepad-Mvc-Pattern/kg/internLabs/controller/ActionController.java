package controller;

public interface ActionController {
    void doAction();
}
