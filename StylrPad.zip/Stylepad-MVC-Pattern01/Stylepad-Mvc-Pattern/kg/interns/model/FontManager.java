package kg.interns.model;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import kg.interns.viewer.Viewer;

public class FontManager implements ActionListener, ListSelectionListener {
    private Viewer viewer;
    private Font currentFont;
    private Map<String, Set<String>> fontStylesMap;

    public FontManager(Viewer viewer) {
        this.viewer = viewer;
        this.currentFont = viewer.getCurrentContent().getFont();
        initializeFontStylesMap();
    }

    private void initializeFontStylesMap() {
        fontStylesMap = new HashMap<>();
        Font[] allFonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();

        for (Font font : allFonts) {
            String family = font.getFamily().toLowerCase(); // Нормализация регистра
            String fontName = font.getFontName();
            String style = detectStyleFromFontName(fontName);

            fontStylesMap.computeIfAbsent(family, k -> new HashSet<>()).add(style);

            System.out.println("Processing Font: " + fontName + " | Family: " + family + " | Style: " + style);
        }

        for (Map.Entry<String, Set<String>> entry : fontStylesMap.entrySet()) {
            System.out.println("Font Family: " + entry.getKey() + " | Styles: " + entry.getValue());
        }
    }

    private String detectStyleFromFontName(String fontName) {
        String lowerName = fontName.toLowerCase();
        boolean isBold = lowerName.contains("bold") || lowerName.contains("полужирный");
        boolean isItalic = lowerName.contains("italic") || lowerName.contains("курсив");

        if (isBold && isItalic) {
            return "Bold Italic";
        } else if (isBold) {
            return "Bold";
        } else if (isItalic) {
            return "Italic";
        } else {
            return "Regular";
        }
    }

    private String mapStyleToText(int fontStyle) {
        return switch (fontStyle) {
            case Font.PLAIN -> "Regular";
            case Font.ITALIC -> "Italic";
            case Font.BOLD -> "Bold";
            case Font.BOLD | Font.ITALIC -> "Bold Italic";
            default -> null; // Неподдерживаемый стиль
        };
    }

    private int mapTextToStyle(String styleText) {
        return switch (styleText) {
            case "Regular" -> Font.PLAIN;
            case "Italic" -> Font.ITALIC;
            case "Bold" -> Font.BOLD;
            case "Bold Italic" -> Font.BOLD | Font.ITALIC;
            default -> Font.PLAIN;
        };
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
            JList<?> sourceList = (JList<?>) e.getSource();
            String listName = sourceList.getName();
            Object selectedValue = sourceList.getSelectedValue();

            if (listName.equals("FontList")) {
                if (selectedValue != null) {
                    String selectedFont = (String) selectedValue;
                    updateStyleList(selectedFont);
                    updateTextField("fontInputField", selectedFont);
                    updateFont(selectedFont, currentFont.getStyle(), currentFont.getSize());
                }
            } else if (listName.equals("StyleList")) {
                if (selectedValue != null) {
                    String selectedStyle = (String) selectedValue;
                    updateFont(currentFont.getFontName(), mapTextToStyle(selectedStyle), currentFont.getSize());
                    updateTextField("styleInputField", selectedStyle);
                }
            } else if (listName.equals("SizeList")) {
                if (selectedValue != null) {
                    Integer selectedSize = (Integer) selectedValue;
                    updateFont(currentFont.getFontName(), currentFont.getStyle(), selectedSize);
                    updateTextField("sizeInputField", selectedSize.toString());
                }
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();

        if ("ApplyFont".equals(command)) {
            applySelectedFont();
            applyColorFont();
        } else if ("CloseDialog".equals(command) || "CancelFont".equals(command)) {
            viewer.hideFontDialog();
        } else if ("RedColor".equals(command)) {
            viewer.updateSampleLabelColor(Color.RED);
        } else if ("BlueColor".equals(command)) {
            viewer.updateSampleLabelColor(Color.BLUE);
        } else if ("GreenColor".equals(command)) {
            viewer.updateSampleLabelColor(Color.GREEN);
        }
    }

    private void applySelectedFont() {
        try {
            String fontName = getTextFieldValue("fontInputField");
            String fontStyle = getTextFieldValue("styleInputField");
            int fontSize = Integer.parseInt(getTextFieldValue("sizeInputField"));
            Font selectedFont = new Font(fontName, mapTextToStyle(fontStyle), fontSize);

            viewer.setNewFontForTextArea(selectedFont);
            viewer.hideFontDialog();
        } catch (NumberFormatException e) {
            viewer.showError("Please enter a valid size!");
        }
    }

    private void applyColorFont() {
        Color color = viewer.getSampleLabelColor();
        viewer.setNewColorFontForTextArea(color);
        viewer.hideFontDialog();
    }

    private void updateFont(String name, int style, int size) {
        currentFont = new Font(name, style, size);
        viewer.updateSampleLabelFont(currentFont);
    }

    public void updateStyleList(String selectedFont) {
        Set<String> availableStyles = fontStylesMap.getOrDefault(selectedFont.toLowerCase(), Set.of("Regular"));
        JList<String> styleList = (JList<String>) getComponentByName("StyleList");
        if (styleList != null) {
            DefaultListModel<String> model = new DefaultListModel<>();
            for (String style : Arrays.asList("Regular", "Italic", "Bold", "Bold Italic")) {
                if (availableStyles.contains(style)) {
                    model.addElement(style);
                }
            }
            styleList.setModel(model);
            if (!model.isEmpty()) {
                styleList.setSelectedIndex(0);
            } else {
                DefaultListModel<String> fallbackModel = new DefaultListModel<>();
                fallbackModel.addElement("Regular");
                styleList.setModel(fallbackModel);
                styleList.setSelectedIndex(0);
                updateTextField("styleInputField", "Regular");
                updateFont(selectedFont, Font.PLAIN, currentFont.getSize());
            }
        }
    }

    private Component getComponentByName(String name) {
        JDialog fontDialog = viewer.getFontDialog();
        if (fontDialog == null) return null;
        Component[] components = fontDialog.getContentPane().getComponents();
        for (Component component : components) {
            if (name.equals(component.getName())) {
                return component;
            }
            if (component instanceof Container) {
                Component found = findComponentRecursively((Container) component, name);
                if (found != null) return found;
            }
        }
        return null;
    }

    private Component findComponentRecursively(Container container, String name) {
        for (Component component : container.getComponents()) {
            if (name.equals(component.getName())) {
                return component;
            }
            if (component instanceof Container) {
                Component found = findComponentRecursively((Container) component, name);
                if (found != null) return found;
            }
        }
        return null;
    }

    private int getStyleCode(String style) {
        if (style == null) {
            return Font.PLAIN;
        }
        switch (style) {
            case "Italic":
                return Font.ITALIC;
            case "Bold":
                return Font.BOLD;
            case "Bold Italic":
                return Font.BOLD | Font.ITALIC;
            default:
                return Font.PLAIN;
        }
    }

    public String getTextFieldValue(String textFieldName) {
        Component component = getComponentByName(textFieldName);
        if (component instanceof JTextField) {
            return ((JTextField) component).getText();
        }
        return "";
    }

    public void updateTextField(String textFieldName, String value) {
        Component component = getComponentByName(textFieldName);
        if (component instanceof JTextField) {
            ((JTextField) component).setText(value);
        }
    }
}
