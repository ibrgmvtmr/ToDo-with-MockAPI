package server;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class ClientForBackendServer {

    private Socket socket;
    public ClientForBackendServer(String host, int port) {
        try {
            socket = new Socket(host, port);
        } catch (UnknownHostException uhe) {
            System.out.println("Error " + uhe);
        } catch (IOException ioe) {
            System.out.println("Error " + ioe);
        }
    }

    public void sendMessage(String text) {
        try {
            String message = text;
            byte[] data = message.getBytes();
            int fileLength = (int)message.length();
            java.io.OutputStream outputStream = socket.getOutputStream();
            java.io.PrintWriter out = new java.io.PrintWriter(outputStream, true);
            out.println("POST /api/notepad HTTP/1.1");
            out.println("Content-Type: application/json");
            out.println("User-Agent: Nurtelecom"); //here also need to change
            out.println("Accept : */*");
            out.println("Cache-Control: no-cache");
            out.println("Host: 127.0.0.1: 8877");
            out.println("Content-Length: " + fileLength);
            out.println();
            out.flush();

            BufferedOutputStream dataOut = new BufferedOutputStream(socket.getOutputStream());
            dataOut.write(data, 0, fileLength);
            dataOut.flush();
        } catch (java.io.IOException ioe) {
            System.out.println(ioe);
        }
    }

    public String readData() {
        try {
            String text = "" ;
            InputStream input = socket.getInputStream();
            while (true) {
                int unicode = input.read();
                char symbol = (char)unicode;
                text = text + symbol;
                if(input.available() == 0) {
                    break;
                }
            }
            return text;
        } catch (java.io.IOException ioe) {
            System.out.println("Client Error: " + ioe);
            return null;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        String text = "{\"text\":\"" + input + "\"}";
        //host and port need to specify
        ClientForBackendServer client = new ClientForBackendServer("127.0.0.1", 8877);
        client.sendMessage(text);
        String answer = client.readData();
        System.out.println(answer);
    }

}
