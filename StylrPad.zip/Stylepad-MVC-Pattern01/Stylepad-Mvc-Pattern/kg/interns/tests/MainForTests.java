package kg.interns.tests;


public class MainForTests {
  public static void main(String[] args) {
    TestSaveAs testSaveAs = new TestSaveAs();

    TestFind testFind = new TestFind();
    testFind.runTest();
  }
}
