package kg.interns.tests;

import kg.interns.viewer.Viewer;
import java.util.HashMap;
import java.util.Map;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JTextField;

public class TestFind {

  private Viewer viewer;
  private Map<String, Component> component;

  public TestFind() {
    viewer = new Viewer();
    component = new HashMap<>();

    component.put("previewLabel" , new JLabel());
    component.put("textField", new JTextField());
    component.put("textPane", new JTextPane());
  }

  public void runTest() {
    testCountOccurrences();
  }

  public void testCountOccurrences() {
    try {
      String fieldText = "I am Test for Find Function!";
      String findText = "Find";

      int count = viewer.countOccurrences(fieldText, findText);
      assertEqual(1, count, "testCountOccurrences");

    } catch (AssertionError ae) {
      System.out.println("testCountOccurrences failed: " + ae.getMessage());
    } catch (Exception e) {
      System.out.println("testCountOccurrences encountered an unexpected error: " + e.getMessage());
    }
  }


  private void assertEqual(Object expected, Object actual, String testName) {
    if (!expected.equals(actual)) {
      throw new AssertionError(String.format("%s failed: expected %s but got %s", testName, expected, actual));
    } else {
      System.out.printf("%s passed%n", testName);
    }
  }





















}
