MAIN_CLASS="kg.interns.main.Main"
OUT_DIR="out"
JAR_NAME="app.jar"

mkdir -p "$OUT_DIR"

echo "Compiling Java files..."
javac -d "$OUT_DIR" kg/interns/**/*.java
if [ $? -ne 0 ]; then
    echo "Compilation failed!"
    exit 1
fi

echo "Creating JAR file..."
jar cfe "$JAR_NAME" "$MAIN_CLASS" -C "$OUT_DIR" .
if [ $? -ne 0 ]; then
    echo "Failed to create JAR file!"
    exit 1
fi

echo "Running the application..."
java -jar "$JAR_NAME"

echo "Cleaning up..."
rm -rf "$OUT_DIR" "$JAR_NAME"

echo "Cleanup complete."
