package kg.interns.model;

import kg.interns.viewer.Viewer;
import kg.interns.controller.ActionController;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.BadLocationException;
import javax.swing.text.ElementIterator;
import javax.swing.text.AbstractDocument;
import javax.swing.text.StyleConstants;
import javax.swing.text.AttributeSet;
import javax.swing.text.Element;
import javax.swing.ImageIcon;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.FontMetrics;
import java.awt.Font;
import java.awt.Image;
import java.awt.print.PrinterException;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.util.ArrayList;
import java.util.List;

public class PrintDocument implements ActionController, Printable {
    private Viewer viewer;
    private DefaultStyledDocument styledDocument;
    private Font fontForPrinting;
    private Object[] documentLines;
    private List<Object> listText;
    private int[] pageBreaks;

    public PrintDocument(Viewer viewer) {
        this.viewer = viewer;
    }

    public PrintDocument(DefaultStyledDocument styledDocument, Font fontOfField) {
        this.styledDocument = styledDocument;
        this.fontForPrinting = fontOfField;
    }

    @Override
    public void doAction() {
        viewer.showPrintDialog();
    }

    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {

        Graphics2D graphics2D = (Graphics2D) graphics;
        graphics2D.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
        graphics2D.setFont(fontForPrinting);

        FontMetrics metrics = graphics.getFontMetrics(fontForPrinting);
        // Height of font
        int lineHeight = metrics.getHeight();

        // Width of page
        int widthPage = (int) (pageFormat.getImageableWidth() - 100);


        if (pageBreaks == null) {
            // Initialize text
            initStyleDocument(lineHeight, widthPage, metrics);
            int linesPerPage = (int) ((pageFormat.getImageableHeight() - 50) / lineHeight);
            int numBreaks = (documentLines.length - 1) / linesPerPage;
            pageBreaks = new int[numBreaks];
            for (int i = 0; i < numBreaks; i++) {
                pageBreaks[i] = (i + 1) * linesPerPage;
            }
        }


        // Reset all to null
        if (pageIndex > pageBreaks.length) {
            clearAllObjects();
            return NO_SUCH_PAGE;
        }

        int x = 50;
        int y = 10;

        int start = (pageIndex == 0) ? 0 : pageBreaks[pageIndex - 1];
        int end = (pageIndex == pageBreaks.length) ? documentLines.length : pageBreaks[pageIndex];
        for (int line = start; line < end; line++) {
            y = y + lineHeight;

            Object textLine = documentLines[line];

            // If textLine contains text or image print it
            if (textLine != null && textLine instanceof String) {
                String text = (String) textLine;
                graphics.drawString(text, x, y);
            } else if (textLine instanceof Image) {
                Image image = (Image) documentLines[line];
                graphics.drawImage(image, x, y, null);
            }
        }

        // Add counter of pages
        Font amountPage = new Font("Arial", Font.BOLD, 15);
        graphics.setFont(amountPage);
        graphics.drawString("Page " + (pageIndex + 1),
                (int) (pageFormat.getImageableWidth() - 80),
                (int) (pageFormat.getImageableHeight() - 25));


        return PAGE_EXISTS;
    }

    public void initStyleDocument(int lineHeight, int widthPage, FontMetrics metrics) {
        if (documentLines == null) {
            listText = new ArrayList<>();

            ElementIterator iterator = new ElementIterator(styledDocument);
            Element element;
            while ((element = iterator.next()) != null) {
                AttributeSet attributeSet = element.getAttributes();
                if (element.isLeaf()) {
                    int start = element.getStartOffset();
                    int end = element.getEndOffset();

                    try {
                        if (attributeSet.containsAttribute(AbstractDocument.ElementNameAttribute,
                                StyleConstants.IconElementName)) {
                            ImageIcon icon = (ImageIcon) StyleConstants.getIcon(attributeSet);
                            Image image = icon.getImage();

                            int imageWidth = image.getWidth(null);
                            int imageHeight = image.getHeight(null);
                            if (imageWidth > 495) {
                                int scaledHeight = (int) (((double) 495 / imageWidth) * imageHeight);
                                image.getScaledInstance(495, scaledHeight, Image.SCALE_SMOOTH);
                            }
                            listText.add(image);

                            int freeLinesForImage = imageHeight / lineHeight;
                            for (int i = 0; i <= freeLinesForImage; i++) {
                                listText.add(null);
                            }
                        } else {
                            String text = styledDocument.getText(start, end - start);
                            if (text != null) {
                                int widthLine = metrics.stringWidth(text);
                                if (widthLine < widthPage) {
                                    listText.add(text);
                                } else {
                                    StringBuilder temp = new StringBuilder();
                                    int count = 0;
                                    for (int i = 0; i < text.length(); i++) {
                                        char symbol = text.charAt(i);
                                        temp.append(symbol);
                                        int widthOfString = metrics.stringWidth(temp.toString());
                                        if (widthOfString > widthPage) {
                                            int whiteSpace = temp.lastIndexOf(" ");
                                            if (whiteSpace == -1) {
                                                listText.add(temp.toString());
                                            } else {
                                                listText.add(temp.substring(0, whiteSpace));
                                                i = count + whiteSpace;
                                                count = count + whiteSpace + 1;
                                            }
                                            temp.setLength(0);
                                        }
                                    }
                                    listText.add(temp.toString());
                                }
                            }
                        }
                    } catch (BadLocationException ble) {
                        System.out.println("Exception: " + ble);
                    }
                }
                documentLines = new Object[listText.size()];

                int index = 0;
                for (Object elementList : listText) {
                    documentLines[index] = elementList;
                    index = index + 1;
                }
            }
        }
    }

    // Clearing all useless variables
    public void clearAllObjects() {
        for (int i = 0; i < documentLines.length; i++) {
            documentLines[i] = null;
        }

        listText.clear();
        pageBreaks = null;
        documentLines = null;
        listText = null;
    }
}
