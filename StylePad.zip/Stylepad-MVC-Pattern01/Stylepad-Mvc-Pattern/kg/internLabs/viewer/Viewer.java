package viewer;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;
import javax.swing.text.*;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.text.Highlighter;
import javax.swing.text.DefaultHighlighter;

import controller.Controller;
import controller.MyDocumentListener;
import controller.PrintDocument;

public class Viewer {

  private JFrame mainFrame;
  private JTextPane textPane;
  private JFileChooser fileChooser;
  private JDialog fontDialog;
  private JDialog findDialog;
  private JLabel previewLabel;
  private JTextField textField;
  private JButton button;
  private int lastIndex = -1;
  private int totalOccurrences = 0;
  private int currentOccurrence = 0;
  private JMenuItem menuItem;
  private JTextField lineNumberField;
  private JDialog goToDialog;
  private JFrame frameAbout;
  private JTextField textFind;
  private StatusBarPanel statusBarPanel;
  private Controller controller;
  private JCheckBox caseSensitiveBox;
  private File currentFile;
  private JMenuItem saveAs;


  public Viewer() {
    controller = new Controller(this);

    frameAbout = new JFrame();
    statusBarPanel = new StatusBarPanel();
    mainFrame = createMainFrame(controller);
  }

  public JFrame createMainFrame(Controller controller) {

    JMenuBar menuBar = createMenuBar(controller);
    JToolBar toolBar = createToolBar(controller);

    JPanel editorArea = createEditorArea();

    JPanel statusBar = statusBarPanel.getStatusPanel();
    editorArea.add("South", statusBar);

    ImageIcon icon = new ImageIcon("logo/notepad_icon_48.png");

    JFrame mainFrame = new JFrame();
    mainFrame.setSize(600, 600);
    mainFrame.setTitle("Command Design Pattern Stylepad MVC Pattern");
    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainFrame.add(toolBar, BorderLayout.NORTH);
    mainFrame.setIconImage(icon.getImage());
    mainFrame.add(editorArea);
    mainFrame.setJMenuBar(menuBar);
    mainFrame.setLocationRelativeTo(null);
    mainFrame.setVisible(true);

    return mainFrame;
  }

  private JMenuBar createMenuBar(Controller controller) {

    JMenu fileMenu = createFileMenu(controller);
    JMenu editMenu = createEditMenu(controller);
    JMenu formatMenu = createFormatMenu(controller);
    JMenu viewMenu = createViewMenu(controller);
    JMenu helpMenu = createHelpMenu(controller);

    JMenuBar menuBar = new JMenuBar();

    menuBar.add(fileMenu);
    menuBar.add(editMenu);
    menuBar.add(formatMenu);
    menuBar.add(viewMenu);
    menuBar.add(helpMenu);

    return menuBar;
  }

  private JMenu createFileMenu(Controller controller) {

    JMenuItem newFile = new JMenuItem("New file");
    newFile.setIcon(new ImageIcon("resources1/new.png"));
    newFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
    newFile.addActionListener(controller);
    newFile.setActionCommand("New file");

    JMenuItem openFile = new JMenuItem("Open file");
    openFile.setIcon(new ImageIcon("resources1/open.png"));
    openFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
    openFile.addActionListener(controller);
    openFile.setActionCommand("Open file");

    JMenuItem openImage = new JMenuItem("Open image");
    openImage.setIcon(new ImageIcon("resources1/open.png"));
    openImage.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
    openImage.addActionListener(controller);
    openImage.setActionCommand("OpenImage");

    JMenuItem save = new JMenuItem("Save");
    save.setIcon(new ImageIcon("resources1/save.png"));
    save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
    save.addActionListener(controller);
    save.setActionCommand("Save");

    saveAs = new JMenuItem("Save as");
    saveAs.setIcon(new ImageIcon("resources1/saveas.png"));
    saveAs.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK | ActionEvent.SHIFT_MASK));
    saveAs.addActionListener(controller);
    saveAs.setActionCommand("Save as");

    JMenuItem print = new JMenuItem("Print...");
    print.setIcon(new ImageIcon("resources1/print.png"));
    print.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
    print.addActionListener(controller);
    print.setActionCommand("Print");

    JMenuItem exit = new JMenuItem("Exit");
    exit.setIcon(new ImageIcon("resources1/exit.png"));
    exit.addActionListener(controller);
    exit.setActionCommand("Exit");

    JMenu fileMenu = new JMenu("File");
    fileMenu.setMnemonic('F');

    fileMenu.add(newFile);
    fileMenu.add(openFile);
    fileMenu.add(openImage);
    fileMenu.add(save);
    fileMenu.add(saveAs);
    fileMenu.addSeparator();
    fileMenu.add(print);
    fileMenu.addSeparator();
    fileMenu.add(exit);

    return fileMenu;
  }

  public JMenu createEditMenu(Controller controller) {

    JMenuItem cut = new JMenuItem("Cut");
    cut.setIcon(new ImageIcon("resources1/cut.png"));
    cut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
    cut.addActionListener(controller);
    cut.setActionCommand("Cut");

    JMenuItem copy = new JMenuItem("Copy");
    copy.setIcon(new ImageIcon("resources1/copy.png"));
    copy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
    copy.addActionListener(controller);
    copy.setActionCommand("Copy");

    JMenuItem paste = new JMenuItem("Paste");
    paste.setIcon(new ImageIcon("resources1/paste.png"));
    paste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.CTRL_MASK));
    paste.addActionListener(controller);
    paste.setActionCommand("Paste");

    JMenuItem clear = new JMenuItem("Clear");
    clear.setIcon(new ImageIcon("resources1/clear.png"));
    clear.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, ActionEvent.CTRL_MASK));
    clear.addActionListener(controller);
    clear.setActionCommand("Clear");

    JMenuItem find = new JMenuItem("Find");
    find.setIcon(new ImageIcon("resources1/find.png"));
    find.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, ActionEvent.CTRL_MASK));
    find.addActionListener(controller);
    find.setActionCommand("Find");
    setFindMenuItem(find);
    find.setEnabled(false);

    JMenuItem findMore = new JMenuItem("Find more");
    findMore.setIcon(new ImageIcon("resources1/findmore.png"));
    findMore.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, ActionEvent.SHIFT_MASK));
    findMore.addActionListener(controller);
    findMore.setActionCommand("Findmore");

    JMenuItem go = new JMenuItem("Go");
    go.setIcon(new ImageIcon("resources1/go.png"));
    go.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, ActionEvent.CTRL_MASK));
    go.addActionListener(controller);
    go.setActionCommand("Go");

    JMenuItem markerAll = new JMenuItem("Marker all");
    markerAll.setIcon(new ImageIcon("resources1/markerall.png"));
    markerAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
    markerAll.addActionListener(controller);
    markerAll.setActionCommand("Marker all");

    JMenuItem replace = new JMenuItem("Replace");
    replace.setIcon(new ImageIcon("resources1/replace.png"));
    replace.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T, ActionEvent.CTRL_MASK));
    replace.addActionListener(controller);
    replace.setActionCommand("Replace");

    JMenuItem timeAndDate = new JMenuItem("Time and date");
    timeAndDate.setIcon(new ImageIcon("resources1/timeanddate.png"));
    timeAndDate.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T, ActionEvent.CTRL_MASK));
    timeAndDate.addActionListener(controller);
    timeAndDate.setActionCommand("Time_and_date");

    JMenu editMenu = new JMenu("Edit");
    editMenu.setMnemonic('E');

    editMenu.add(copy);
    editMenu.add(cut);
    editMenu.add(paste);
    editMenu.add(clear);
    editMenu.addSeparator();
    editMenu.add(find);
    editMenu.add(findMore);
    editMenu.addSeparator();
    editMenu.add(go);
    editMenu.addSeparator();
    editMenu.add(markerAll);
    editMenu.add(replace);
    editMenu.add(timeAndDate);

    return editMenu;
  }

  public JMenu createFormatMenu(Controller controller) {

    JMenuItem wordSpace = new JMenuItem("Word Space");
    wordSpace.setIcon(new ImageIcon("resources1/wordspace.png"));
    wordSpace.addActionListener(controller);
    wordSpace.setActionCommand("Word Space");

    JMenuItem font = new JMenuItem("Font");
    font.setIcon(new ImageIcon("resources1/font.png"));
    font.addActionListener(controller);
    font.setActionCommand("Font");

    JMenu formatMenu = new JMenu("Format");
    formatMenu.setMnemonic('O');

    formatMenu.add(font);
    formatMenu.add(wordSpace);

    return formatMenu;
  }

  public JMenu createViewMenu(Controller controller) {

    JRadioButtonMenuItem statusSpace = new JRadioButtonMenuItem("Status space", false);
    statusSpace.setIcon(new ImageIcon("resources1/statusspace.png"));
    statusSpace.addActionListener(controller);
    statusSpace.setActionCommand("Status_space");

    JMenu scaleJM = new JMenu("Scale");
    scaleJM.setIcon(new ImageIcon("resources1/scale.png"));
    scaleJM.addActionListener(controller);
    scaleJM.setActionCommand("Scale");

    JMenuItem zoomInItem = new JMenuItem("Scale In");
    zoomInItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_PLUS, ActionEvent.CTRL_MASK));
    zoomInItem.setIcon(new ImageIcon("resources1/sizeIn.png"));
    zoomInItem.addActionListener(controller);
    zoomInItem.setActionCommand("ScaleIn");

    JMenuItem zoomOutItem = new JMenuItem("Scale Out");
    zoomOutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_MINUS, ActionEvent.CTRL_MASK));
    zoomOutItem.setIcon(new ImageIcon("resources1/sizeOut.png"));
    zoomOutItem.addActionListener(controller);
    zoomOutItem.setActionCommand("ScaleOut");

    JMenuItem defaultZoomItem = new JMenuItem("Restore Default Scale");
    defaultZoomItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_0, ActionEvent.CTRL_MASK));
    defaultZoomItem.setIcon(new ImageIcon("resources1/restoreScale.png"));
    defaultZoomItem.addActionListener(controller);
    defaultZoomItem.setActionCommand("DefaultScale");

    scaleJM.add(zoomInItem);
    scaleJM.add(zoomOutItem);
    scaleJM.add(defaultZoomItem);

    JMenu viewMenu = new JMenu("View");
    viewMenu.setMnemonic('V');

    viewMenu.add(scaleJM);
    viewMenu.add(statusSpace);

    return viewMenu;
  }

  public JMenu createHelpMenu(Controller controller) {
    JMenuItem help = new JMenuItem("About");
    help.addActionListener(controller);
    help.setActionCommand("About");

    JMenu helpMenu = new JMenu("About");
    helpMenu.setMnemonic('A');

    helpMenu.add(help);

    return helpMenu;
  }

  private JButton createToolButton(String iconPath, String tooltip) {
    ImageIcon icon = new ImageIcon(iconPath);
    JButton button = new JButton(icon);
    button.setToolTipText(tooltip);
    return button;
  }

  private JToolBar createToolBar(Controller controller) {

    JToolBar toolBar = new JToolBar();

    JButton newFileButton = createToolButton("resources2/new.png", "New file");
    newFileButton.addActionListener(controller);
    newFileButton.setActionCommand("New file");
    toolBar.add(newFileButton);

    JButton openFileButton = createToolButton("resources2/open.png", "Open file");
    openFileButton.addActionListener(controller);
    openFileButton.setActionCommand("Open file");
    toolBar.add(openFileButton);

    JButton saveFileButton = createToolButton("resources2/save.png", "Save file");
    saveFileButton.addActionListener(controller);
    saveFileButton.setActionCommand("Save as");
    toolBar.add(saveFileButton);

    JButton cutButton = createToolButton("resources2/cut.png", "Cut");
    cutButton.addActionListener(controller);
    cutButton.setActionCommand("Cut");
    toolBar.add(cutButton);

    JButton copyButton = createToolButton("resources2/copy.png", "Copy");
    copyButton.addActionListener(controller);
    copyButton.setActionCommand("Copy");
    toolBar.add(copyButton);

    JButton pasteButton = createToolButton("resources2/paste.png", "Paste");
    pasteButton.addActionListener(controller);
    pasteButton.setActionCommand("Paste");
    toolBar.add(pasteButton);

    return toolBar;
  }


  public void setFindMenuItem(JMenuItem menuItem) {
    this.menuItem = menuItem;
  }

  public JPanel createEditorArea() {

    JTextComponent editor = createEditor();
    Border raisedetched = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
    Border empty = new EmptyBorder(-2, -2, -2, -2);
    Border compound = BorderFactory.createCompoundBorder(empty, raisedetched);

    JScrollPane scrollPane = new JScrollPane();
    scrollPane.setBorder(compound);
    JViewport viewPort = scrollPane.getViewport();
    viewPort.add(editor);

    Color colorBackground = new Color(230, 230, 230);
    JPanel panel = new JPanel();
    panel.setBackground(colorBackground);
    panel.setLayout(new BorderLayout());
    panel.setBorder(compound);
    panel.add(scrollPane);

    return panel;
  }

  protected JTextComponent createEditor() {
    StyleContext sc = new StyleContext();
    DefaultStyledDocument doc = new DefaultStyledDocument(sc);
    textPane = new JTextPane(doc);
    textPane.getDocument().addDocumentListener(new MyDocumentListener(this));
    textPane.setFont(new Font("Arial", Font.PLAIN, 20));

    return textPane;
  }

  public void showPrintDialog() {
    String textOfPane = textPane.getText();
    Font fontOfField = textPane.getFont();

    PrintDocument printDocument = new PrintDocument(textOfPane, fontOfField);

    PrinterJob job = PrinterJob.getPrinterJob();
    job.setPrintable(printDocument);

    boolean doPrint = job.printDialog();
    if (doPrint) {
      try {
        job.print();
      } catch (PrinterException pe) {
        JOptionPane.showMessageDialog(null, pe);
      }
      JOptionPane.showMessageDialog(null, "Done Printing",
              "Information", JOptionPane.INFORMATION_MESSAGE);
    }
  }

  public Document getDocument() {
    return textPane.getDocument();
  }

  public String getContent() {
    return textPane.getText();
  }

  public StyledDocument getStyledDocument() {
    return textPane.getStyledDocument();
  }

  public File showSaveFileDialog() {
    if (fileChooser == null) {
      fileChooser = new JFileChooser();
    }
    File file = null;

    int returnVal = fileChooser.showSaveDialog(null);
    if (returnVal == JFileChooser.APPROVE_OPTION) {
      file = fileChooser.getSelectedFile();
    }

    return file;
  }

  public File showOpenFileDialog() {
    if (fileChooser == null) {
      fileChooser = new JFileChooser();
    }
    File file = null;

    int returnVal = fileChooser.showOpenDialog(null);
    if (returnVal == JFileChooser.APPROVE_OPTION) {
      file = fileChooser.getSelectedFile();
    }

    return file;
  }

  public void showNotFoundFile() {
    JOptionPane.showMessageDialog(null, "File not found.");
  }

  public File getCurrentFile() {
    return currentFile;
  }

  public void setCurrentFile(File file) {
    this.currentFile = file;
  }

  public void setContentOnTextArea(String fileContent) {
    textPane.setText(fileContent);
  }

  public void update(Document document) {
    if (textPane.getDocument() != null) {
      textPane.getDocument().removeUndoableEditListener(null);
      textPane.getDocument().removeDocumentListener(null);
    }
    document.addUndoableEditListener(null);
    document.addDocumentListener(new MyDocumentListener(this));
    textPane.setDocument(document);
  }

  public void updateOpen(String content) {
    textPane.setText(content);
  }

  public void showResultSaveDocumentIntoModel(boolean result) {
    if (result) {
      JOptionPane.showMessageDialog(null, "File saved successfully");
    } else {
      JOptionPane.showMessageDialog(null, "File did't save", "ERROR", JOptionPane.ERROR_MESSAGE);
    }

  }

  public void cut() {
    textPane.cut();
  }

  public void paste() {
    textPane.paste();
  }

  public void copy() {
    textPane.copy();
  }

  public void scaleIn() {
    Font getFont = textPane.getFont();
    float getFontSize = getFont.getSize();
    float changeFontSize = getFontSize * 1.2F;

    Font newFont = new Font(getFont.getFontName(), getFont.getStyle(), (int) changeFontSize);

    textPane.setFont(newFont);
  }

  public void scaleOut() {
    Font getFont = textPane.getFont();
    float getFontSize = getFont.getSize();
    float changeFontSize = getFontSize / 1.2F;

    Font newFont = new Font(getFont.getFontName(), getFont.getStyle(), (int) changeFontSize);

    textPane.setFont(newFont);
  }

  public void defaultScale() {
    Font getFont = textPane.getFont();
    float getFontSize = getFont.getSize();
    float changeFontSize = 20.0F;

    Font newFont = new Font(getFont.getFontName(), getFont.getStyle(), (int) changeFontSize);

    textPane.setFont(newFont);
  }

  public void showFindDialog() {
    if (fontDialog == null) {
      fontDialog = new JDialog();
      fontDialog.setTitle("Find");
      fontDialog.setSize(400, 200);
      fontDialog.setModal(true);
      fontDialog.setResizable(false);

      JPanel panel = new JPanel();
      panel.setLayout(null);

      textField = new JTextField();
      textField.setBounds(90, 18, 185, 30);

      JButton findButton = new JButton("Find Next");
      findButton.setBounds(285, 17, 90, 34);
      findButton.addActionListener(controller);
      findButton.setActionCommand("FindButton");

      JButton cancelButton = new JButton("Cancel");
      cancelButton.addActionListener(controller);
      cancelButton.setActionCommand("Cancel_Find");
      cancelButton.setBounds(285, 50, 90, 34);

      JButton button = new JButton("Ok");
      button.addActionListener(controller);
      button.setActionCommand("Close_Find");
      button.setBounds(300, 130, 80, 30);

      previewLabel = new JLabel("Ready to search");
      previewLabel.setFont(new Font("Arial", Font.PLAIN, 12));
      previewLabel.setBounds(20, 50, 254, 25);
      previewLabel.setBorder(BorderFactory.createEtchedBorder());

      JLabel textLabel = new JLabel("Find what: ");
      textLabel.setFont(new Font("Arial", Font.PLAIN, 15));
      textLabel.setBounds(20, 20, 100, 25);

      panel.add(textLabel);
      panel.add(textField);
      panel.add(button);
      panel.add(findButton);
      panel.add(cancelButton);
      panel.add(previewLabel);

      fontDialog.add(panel);
}

    fontDialog.getRootPane().setDefaultButton(button);
    fontDialog.setLocationRelativeTo(mainFrame);
    fontDialog.setVisible(true);
  }

  public void showFindMoreDialog() {
      if (fontDialog == null) {
          fontDialog = new JDialog();
          fontDialog.setTitle("Find More");
          fontDialog.setSize(400, 165);
          fontDialog.setModal(true);
          fontDialog.setResizable(false);

          JPanel panel = new JPanel();
          panel.setLayout(null);

          textField = new JTextField();
          textField.setBounds(90, 18, 185, 30);

          JLabel textLabel = new JLabel("Find what: ");
          textLabel.setFont(new Font("Arial", Font.PLAIN, 15));
          textLabel.setBounds(20, 20, 100, 25);

          JButton findButton = new JButton("Find");
          findButton.setBounds(285, 17, 90, 34);
          findButton.addActionListener(controller);
          findButton.setActionCommand("FindMoreButton");

          JButton cancelButton = new JButton("Cancel");
          cancelButton.addActionListener(controller);
          cancelButton.setActionCommand("CancelFindMore");
          cancelButton.setBounds(285, 50, 90, 34);

          button = new JButton("Ok");
          button.addActionListener(controller);
          button.setActionCommand("Close_Find");
          button.setBounds(300, 100, 80, 30);

          caseSensitiveBox = new JCheckBox("Case Sensitive");
          caseSensitiveBox.setBounds(20, 60, 150, 25);

          panel.add(textLabel);
          panel.add(textField);
          panel.add(findButton);
          panel.add(cancelButton);
          panel.add(caseSensitiveBox);
          panel.add(button);

          fontDialog.add(panel);
      }

      fontDialog.setLocationRelativeTo(mainFrame);
      fontDialog.setVisible(true);
  }


  public void closeDialog() {
    fontDialog.dispose();
    fontDialog = null;
  }

  public void findMore() {
      String textToFind = textField.getText();
      boolean caseSensitive = caseSensitiveBox.isSelected();
      String textContent = textPane.getText();

      if (textContent.isEmpty()) {
        JOptionPane.showMessageDialog(fontDialog, "Текстовая панель пустая. Нечего искать.");
      } if (!textToFind.isEmpty()) {
        highlightAllOccurrences(textToFind, caseSensitive);
      } else {
        JOptionPane.showMessageDialog(fontDialog, "Введите текст для поиска.");
      }
  }

  public void removeHighlightAll() {
    Highlighter highlighter = textPane.getHighlighter();
    highlighter.removeAllHighlights();
  }

  private void highlightAllOccurrences(String textToFind, boolean caseSensitive) {
    Highlighter highlighter = textPane.getHighlighter();
    highlighter.removeAllHighlights();

    String textContent = textPane.getText();
    int index;

    String searchContent = caseSensitive ? textContent : textContent.toLowerCase();
    String searchText = caseSensitive ? textToFind : textToFind.toLowerCase();

    index = searchContent.indexOf(searchText);
    while (index >= 0) {
        try {
            int end = index + textToFind.length();
            highlighter.addHighlight(index, end, new DefaultHighlighter.DefaultHighlightPainter(Color.LIGHT_GRAY));
            index = searchContent.indexOf(searchText, end);
        } catch (BadLocationException e) {
            e.printStackTrace();
        }
    }
}

  public void findText() {
    String text = textField.getText().trim();

    if (!text.isEmpty()) {
      String documentText = textPane.getText();
      if (lastIndex == -1) {
        totalOccurrences = countOccurrences(documentText, text);
        currentOccurrence = 0;

        if (totalOccurrences == 0) {
          previewLabel.setText("No matches found!");
          return;
        }
      }

      int index = documentText.indexOf(text, lastIndex + 1);
      if (index != -1) {
        lastIndex = index;
        currentOccurrence++;
        textPane.select(index, index + text.length());
        previewLabel.setText(String.format("Match %d of %d", currentOccurrence, totalOccurrences));
      } else {
        previewLabel.setText("Reached end of document.");
        lastIndex = -1;
        currentOccurrence = 0;
      }
    } else {
      previewLabel.setText("Please enter text to find");
    }
  }

  public int countOccurrences(String documentText, String searchText) {
    int count = 0;
    int index = 0;

    while ((index = documentText.indexOf(searchText, index)) != -1) {
      count = count + 1;
      index += searchText.length();
    }

    return count;
  }

  public void resetSearch() {
    lastIndex = -1;
    currentOccurrence = 0;
    totalOccurrences = 0;

    if (previewLabel != null) {
      previewLabel.setText("Ready to search");
    }
    if (textField != null) {
      textField.setText("");
      textField.requestFocus();
      textPane.select(textPane.getCaretPosition(), textPane.getCaretPosition());
    }
  }

  public void enableFind() {
    if (menuItem != null) {
      menuItem.setEnabled(true);
    }
  }

  public void disableFind() {
    if (menuItem != null) {
      menuItem.setEnabled(false);
    }
  }

  public void replace() {
    fontDialog = new JDialog();
    fontDialog.setTitle("Replace");
    fontDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    fontDialog.setLocation(mainFrame.getX() + 140, mainFrame.getY() + 140);
    fontDialog.setSize(290, 200);
    fontDialog.setLayout(new BoxLayout(fontDialog.getContentPane(), BoxLayout.Y_AXIS));
    // content pane - это текстовые поля, метки, кнопки и т.п
    // BoxLayout.Y_AXIS - Компоненты располагаются вертикально, один под другим.
    // BoxLayout.X_AXIS - Компоненты располагаются горизонтально, один рядом с другим.

    JLabel labelFind = new JLabel("Find");
    JTextField textFind = new JTextField();

    JLabel labelReplace = new JLabel("Replace to: ");
    JTextField textReplace = new JTextField();

    JButton replaceButton = new JButton("Replace");
    replaceButton.addActionListener(controller);
    // replaceButton.setActionCommand("ReplaceFunc");

    JButton cancelButton = new JButton("Cancel");
    cancelButton.addActionListener(controller);
    cancelButton.setActionCommand("CloseReplace");
    cancelButton.setBounds(285, 50, 90, 34);


    replaceButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        String a = textFind.getText();
        String b = textReplace.getText();

        String newContent = textPane.getText().replaceAll("(?i)" + Pattern.quote(a), b);
        // System.out.println(Pattern.quote(a));
        textPane.setText(newContent);
        fontDialog.dispose();
      }
    });

    fontDialog.add(labelFind);
    fontDialog.add(textFind);
    fontDialog.add(labelReplace);
    fontDialog.add(textReplace);
    fontDialog.add(replaceButton);
    fontDialog.add(cancelButton);

    fontDialog.setVisible(true);
  }

  //Go to
  public void showGoToDialog() {
    goToDialog = new JDialog(mainFrame, "Go to line", true);
    goToDialog.setSize(300, 150);
    goToDialog.setLayout(new BorderLayout());

    JPanel inputPanel = new JPanel();
    inputPanel.setLayout(new FlowLayout());
    JLabel label = new JLabel("Line number:");
    lineNumberField = new JTextField(10);
    inputPanel.add(label);
    inputPanel.add(lineNumberField);

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new FlowLayout());
    JButton goToButton = new JButton("Go to");
    goToButton.setActionCommand("GoToButton");
    goToButton.addActionListener(controller);
    JButton cancelButton = new JButton("Cancel");
    cancelButton.setActionCommand("CancelGoTo");
    cancelButton.addActionListener(controller);
    buttonPanel.add(goToButton);
    buttonPanel.add(cancelButton);

    goToDialog.add(inputPanel, BorderLayout.CENTER);
    goToDialog.add(buttonPanel, BorderLayout.SOUTH);
    goToDialog.setLocationRelativeTo(mainFrame);
    goToDialog.setVisible(true);
  }

  public void goToLine() {
    String input = lineNumberField.getText().trim();
    try {
      int lineNumber = Integer.parseInt(input);
      Element root = textPane.getDocument().getDefaultRootElement();
      if (lineNumber > 0 && lineNumber <= root.getElementCount()) {
        Element line = root.getElement(lineNumber - 1);
        int start = line.getStartOffset();
        textPane.setCaretPosition(start);
        textPane.requestFocus();
        goToDialog.dispose();
      } else {JOptionPane.showMessageDialog(goToDialog, "The line number is beyond the total number of lines.", "Error", JOptionPane.ERROR_MESSAGE);
      }
    } catch (NumberFormatException ex) {
      JOptionPane.showMessageDialog(goToDialog, "Please enter a valid line number.", "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  public JDialog getGoToDialog() {
    return goToDialog;
  }

  //Marker All
  public void markerAll() {
    String content = textPane.getText();
    if (content.isEmpty()) {
      JOptionPane.showMessageDialog(mainFrame, "Нет текста для выделения");
      return;
    }
    textPane.selectAll();
  }

  public void showFontDialog() {
    FontManager fontManager = new FontManager(this);

    Font[] allFontsInOS = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
    String[] availableFonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
    //String[] fontStyles = {"Regular", "Italic", "Bold", "Bold Italic"};
    Integer[] fontSizes = {8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72};

    fontDialog = new JDialog(mainFrame, "Choose Font");
    fontDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    fontDialog.setLocation(mainFrame.getX() + 140, mainFrame.getY() + 140);
    fontDialog.setSize(530, 530);
    fontDialog.setLayout(null);
    fontDialog.setResizable(false);

    JLabel fontLabel = new JLabel("Font:");
    fontLabel.setBounds(5, 10, 50, 15);

    String initialFont = textPane.getFont().getFontName();
    JTextField fontInputField = new JTextField(initialFont);
    fontInputField.setBounds(5, 27, 200, 30);
    fontInputField.setName("fontInputField");

    JList<String> fontList = new JList<>(availableFonts);
    fontList.setSelectedValue(initialFont, true);
    fontList.setName("FontList");
    fontList.addListSelectionListener(fontManager);

    JScrollPane fontListScroll = new JScrollPane(fontList);
    fontListScroll.setBounds(5, 57, 200, 150);

    JLabel styleLabel = new JLabel("Style:");
    styleLabel.setBounds(225, 10, 50, 15);

    String initialStyle = mapStyleToText(textPane.getFont().getStyle());
    JTextField styleInputField = new JTextField(initialStyle);
    styleInputField.setBounds(225, 27, 150, 30);
    styleInputField.setName("styleInputField");

    JList<String> styleList = new JList<>(new String[]{"Regular", "Italic", "Bold", "Bold Italic"});
    styleList.setSelectedValue(initialStyle, true);
    styleList.setName("StyleList");
    styleList.addListSelectionListener(fontManager);

    JScrollPane styleListScroll = new JScrollPane(styleList);
    styleListScroll.setBounds(225, 57, 150, 150);

    JLabel sizeLabel = new JLabel("Size:");
    sizeLabel.setBounds(395, 10, 50, 15);

    int initialSize = textPane.getFont().getSize();
    JTextField sizeInputField = new JTextField(String.valueOf(initialSize));
    sizeInputField.setBounds(395, 27, 70, 30);
    sizeInputField.setName("sizeInputField");

    JList<Integer> sizeList = new JList<>(fontSizes);
    sizeList.setSelectedValue(initialSize, true);
    sizeList.setName("SizeList");
    sizeList.addListSelectionListener(fontManager);

    JScrollPane sizeListScroll = new JScrollPane(sizeList);
    sizeListScroll.setBounds(395, 37, 70, 170);

    JPanel samplePanel = new JPanel();
    samplePanel.setBounds(225, 217, 240, 100);
    samplePanel.setLayout(new BorderLayout());
    samplePanel.setName("sampleTextPanel");
    samplePanel.setBorder(BorderFactory.createTitledBorder("Preview"));
    previewLabel = new JLabel("AaBbCc");
    previewLabel.setHorizontalAlignment(JLabel.CENTER);
    previewLabel.setFont(textPane.getFont());
    samplePanel.add(previewLabel);

    JButton applyButton = new JButton("Apply");
    applyButton.setBounds(250, 450, 100, 30);
    applyButton.setFocusable(false);
    applyButton.setActionCommand("ApplyFont");
    applyButton.addActionListener(fontManager);

    JButton cancelButton = new JButton("Cancel");
    cancelButton.setBounds(370, 450, 100, 30);
    cancelButton.setFocusable(false);
    cancelButton.setActionCommand("CloseDialog");
    cancelButton.addActionListener(controller);

    fontDialog.add(applyButton);
    fontDialog.add(cancelButton);
    fontDialog.add(fontLabel);
    fontDialog.add(fontInputField);
    fontDialog.add(fontListScroll);
    fontDialog.add(styleLabel);
    fontDialog.add(styleListScroll);
    fontDialog.add(styleInputField);
    fontDialog.add(sizeLabel);
    fontDialog.add(sizeInputField);
    fontDialog.add(sizeListScroll);
    fontDialog.add(samplePanel);
    fontDialog.setVisible(true);
  }

  private String mapStyleToText(int fontStyle) {
    return switch (fontStyle) {
      case Font.PLAIN -> "Regular";
      case Font.ITALIC -> "Italic";
      case Font.BOLD -> "Bold";
      default -> "Bold Italic";
    };
  }

  public JTextPane getCurrentContent() {
    return textPane;
  }

  public JDialog getFontDialog() {
    return fontDialog;
  }

  public void hideFontDialog() {
    fontDialog.setVisible(false);
  }

  public void updateSampleLabelFont(Font font) {
    previewLabel.setFont(font);
  }

  public void setNewFontForTextArea(Font font) {
    textPane.setFont(font);
  }

  public void showError(String errorMessage) {
    JOptionPane.showMessageDialog(
    mainFrame,
    errorMessage,
    "Error",
    JOptionPane.ERROR_MESSAGE
    );
  }
  public void insertCurrentDateTime() {
    LocalDateTime now = LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm dd.MM.yyyy");
    String formatted = now.format(formatter);
    int position = textPane.getCaretPosition();
    try {
      textPane.getDocument().insertString(position, formatted, null);
    } catch (BadLocationException ble) {
      System.out.println("Error inserting date and time: " + ble);
    }
  }

  public void clearTextArea() {
    textPane.setText("");
  }

  public void insertImage() {
    File file = showOpenFileDialog();
    if (file != null) {
      Icon icon = new ImageIcon(file.getAbsolutePath());
      textPane.insertIcon(icon);
    }
  }

  // Status menu
  //---------------------------------------------
  public void showStatusSpace(boolean flag) {
    statusBarPanel.setVisiblePanel(flag);
  }
  public void setAmountOfSymbols(int symbols, int lines) {
    statusBarPanel.setAmountOfSymbols(symbols, lines);
  }

  // About menu
  //----------------------------------------------

  /**
  * This method shows the frane "About" Describing the Stylepad.
  *
  * @param show determing either "About" will be shown or not.
  */
  public void frameAbout(boolean show) {
    frameAbout.setTitle("Command Design Pattern Stylepad MVC About");

    Font font = new Font("Calibri", Font.PLAIN, 14); // Font for main text

    JPanel logoPanel = new JPanel(); // Logo Panel is placement only for Command Design Pattern Logo
    logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
    logoPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));

    JSeparator jSeparator = new JSeparator(JSeparator.HORIZONTAL); // Creating a horizontal separator between Logo and Main text
    jSeparator.setForeground(Color.GRAY);
    jSeparator.setBounds(0, 0, 600, 1); // Setting a thickness of a separator
    jSeparator.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0)); // Setting a thickness

    JLabel logoLabel = new JLabel(new ImageIcon("logo/Command Design Pattern Logo.png")); // The logo of Command Design Pattern

    logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    logoPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Set a blank space between label and separator
    logoPanel.add(logoLabel);
    logoPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Set a blank space
    logoPanel.add(jSeparator, BorderLayout.LINE_START);
    logoPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Set a blank space

    JPanel textPanel = new JPanel(); // From here textPanel is serving as placement for text
    textPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0)); // Create an invisible border with a margin from the left

    textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS)); // Text will be formed evenly in y-axis
    JLabel text = new JLabel("This stylepad was created by Command Design Pattern."); // Several jlabels for better handling in panel
    JLabel text2 = new JLabel("Start of the project: 18.10.2024");
    JLabel team1 = new JLabel("Team: Manap Koshoev, Aidai Kydykbekova, Viktor Shishkin,");
    JLabel team2 = new JLabel("Gulkaiyr Toktomusheva, Daniil Kovalenko, Kirill Novikov,");
    JLabel team3 = new JLabel("Asman Nurmanbetov, Albert Gadiev.");

    text.setAlignmentX(Component.LEFT_ALIGNMENT); // Set text to the left
    text2.setAlignmentX(Component.LEFT_ALIGNMENT);
    team1.setAlignmentX(Component.LEFT_ALIGNMENT);
    team2.setAlignmentX(Component.LEFT_ALIGNMENT);
    team3.setAlignmentX(Component.LEFT_ALIGNMENT);

    text.setFont(font); // Set font to the text
    text2.setFont(font);
    team1.setFont(font);
    team2.setFont(font);
    team3.setFont(font);

    textPanel.add(text); // Add text to panel
    textPanel.add(text2);
    textPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Place a blank space between texts
    textPanel.add(team1);
    textPanel.add(team2);
    textPanel.add(team3);

    JPanel iconPanel = new JPanel(); // Panel that serves as placement for stylepad logo
    JLabel notepadIcon = new JLabel(new ImageIcon("logo/notepad_icon_48.png"));
    iconPanel.add(notepadIcon);

    JPanel buttonPanel = new JPanel(); // Place a button "OK". If pressed the "About" Window will close
    JButton okButton = new JButton("OK");
    okButton.addActionListener(controller);
    okButton.setActionCommand("OK");
    buttonPanel.add(okButton);

    // Adding all panels to the frame
    frameAbout.setForeground(Color.WHITE); // Set foreground to white (Doesn't change anything)
    frameAbout.add(logoPanel, BorderLayout.NORTH); // Place logo panel at the top
    frameAbout.add(textPanel, BorderLayout.CENTER); // Place panel with text at the center
    frameAbout.add(iconPanel, BorderLayout.WEST); // Place icon panel to the left
    frameAbout.add(buttonPanel, BorderLayout.SOUTH); // Place panel with button at the bottom
    frameAbout.setResizable(false); // The window cannot be resizable and cannot be fullscreen
    frameAbout.setSize(600, 400); // Set size
    frameAbout.setLocation(470, 200); // The window will appear at the center of the screen (I guess)
    frameAbout.setVisible(show); // Window will be visible by the controller of JMenuItem "About"
  }

  public boolean suggestUserToSaveFile() {
    String[] options = {"Save", "Not Save"};

    int answer = JOptionPane.showOptionDialog(mainFrame,
        "Would you like to save current Document?",
        "Suggest to save File",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,
        options,
        options[0]);

    if (answer == JOptionPane.NO_OPTION) {
      return false;
    }

    return true;
  }

  public void clickSaveAs() {
    saveAs.doClick();
  }

}
