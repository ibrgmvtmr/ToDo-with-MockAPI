package controller;

import viewer.Viewer;

import java.io.IOException;
import java.io.File;
import javax.swing.text.Document;
import java.io.FileInputStream;
import java.io.ObjectInputStream;


public class OpenDocument implements ActionController {

  private Viewer viewer;

  public OpenDocument(Viewer viewer) {
    this.viewer = viewer;
  }


    @Override
    public void doAction() {
        File file = viewer.showOpenFileDialog();
        if (file != null) {
            Document dataFromFile = openDocument(file);
            if (dataFromFile != null) {
                viewer.update(dataFromFile);
            } else {
                viewer.showNotFoundFile();
            }
        } else {
            viewer.showNotFoundFile();
        }
    }


    public Document openDocument(File file) {

      FileInputStream fileInputStream = null;
      ObjectInputStream objectInputStream = null;

      try {
        fileInputStream = new FileInputStream(file);
        objectInputStream = new ObjectInputStream(fileInputStream);

        Document dataFromFile = (Document)objectInputStream.readObject();
        return dataFromFile;
      } catch (ClassNotFoundException cne) {
          System.out.println("cne" + cne);
      } catch (IOException ioe) {
          System.out.println("ioe" + ioe);
      } finally {
        try {
            if(fileInputStream != null) {
                fileInputStream.close();
            }
            if(objectInputStream != null) {
                objectInputStream.close();
            }
        } catch (IOException ioe) {
            System.out.println("ioe" + ioe);
        }
        viewer.setCurrentFile(file);
      }
      return null;
    }

  }
