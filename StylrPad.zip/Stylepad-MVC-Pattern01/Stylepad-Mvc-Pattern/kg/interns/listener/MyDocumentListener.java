package kg.interns.listener;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.StyledDocument;

import kg.interns.viewer.Viewer;
import kg.interns.model.SaveAsDocument;

import java.io.File;

public class MyDocumentListener implements DocumentListener {

  private Viewer viewer;
  private File tempFile;
  private SaveAsDocument saveAsDocument;

  public MyDocumentListener(Viewer viewer) {
    this.viewer = viewer;
    tempFile = null;
    saveAsDocument = new SaveAsDocument(null);
  }

  public void insertUpdate(DocumentEvent e) {
    updateStatus();
    updateSymbolLength();
    saveToTempFile();
  }

  public void removeUpdate(DocumentEvent e) {
    updateStatus();
    updateSymbolLength();
    saveToTempFile();
  }

  public void changedUpdate(DocumentEvent e) {
    updateStatus();
    updateSymbolLength();
    saveToTempFile();
  }

  private void updateStatus() {
    updateFindStatus();
  }

  private void updateFindStatus() {
    Document document = viewer.getDocument();
    if (document.getLength() == 0) {
      viewer.disableFind();
    } else {
      viewer.enableFind();
    }
  }

  public void updateSymbolLength() {
    StyledDocument styledDocument = viewer.getStyledDocument();
    int symbolCount = 0;
    int lineCount = 1;

    try {
      String text = styledDocument.getText(0, styledDocument.getLength());
      String[] lines = text.split("\n");
      lineCount = lines.length;

      if (lines.length > 0) {
        symbolCount = lines[lines.length - 1].length();
      }
    } catch (BadLocationException ex) {
      ex.printStackTrace();
    }

    viewer.setAmountOfSymbols(symbolCount, lineCount);
  }

  private void saveToTempFile() {

    if (tempFile == null) {
      String projectRoot = System.getProperty("user.dir");
      System.out.println(projectRoot);
      tempFile = new File(projectRoot, "tempFile.txt");
      tempFile.deleteOnExit();
    }

    Document currentDocument = viewer.getDocument();

    saveAsDocument.saveToFile(tempFile, currentDocument);
  }

}
