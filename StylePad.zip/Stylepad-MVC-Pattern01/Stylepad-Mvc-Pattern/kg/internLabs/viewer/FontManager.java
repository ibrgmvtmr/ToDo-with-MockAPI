package viewer;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FontManager implements ActionListener, ListSelectionListener {
    private Viewer viewer;
    private Font currentFont;

    public FontManager(Viewer viewer) {
        this.viewer = viewer;
        this.currentFont = viewer.getCurrentContent().getFont();
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
            JList<?> sourceList = (JList<?>) e.getSource();
            String listName = sourceList.getName();
            Object selectedValue = sourceList.getSelectedValue();

            if (listName.equals("FontList")) {
                updateFont((String) selectedValue, currentFont.getStyle(), currentFont.getSize());
                updateTextField("fontInputField", selectedValue.toString());
            } else if (listName.equals("StyleList")) {
                updateFont(currentFont.getFontName(), getStyleCode((String) selectedValue), currentFont.getSize());
                updateTextField("styleInputField", selectedValue.toString());
            } else if (listName.equals("SizeList")) {
                updateFont(currentFont.getFontName(), currentFont.getStyle(), (Integer) selectedValue);
                updateTextField("sizeInputField", selectedValue.toString());
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        String command = event.getActionCommand();

        if ("ApplyFont".equals(command)) {
            applySelectedFont();
        } else if ("CloseDialog".equals(command) || "CancelFont".equals(command)) {
            viewer.hideFontDialog();
        }
    }

    private void updateFont(String name, int style, int size) {
        currentFont = new Font(name, style, size);
        viewer.updateSampleLabelFont(currentFont);
    }

    private void applySelectedFont() {
        try {
            String fontName = getTextFieldValue("fontInputField");
            String fontStyle = getTextFieldValue("styleInputField");
            int fontSize = Integer.parseInt(getTextFieldValue("sizeInputField"));
            Font selectedFont = new Font(fontName, getStyleCode(fontStyle), fontSize);

            viewer.setNewFontForTextArea(selectedFont);
            viewer.hideFontDialog();
        } catch (NumberFormatException e) {
            viewer.showError("Please enter a valid size!");
        }
    }

    private int getStyleCode(String style) {
        switch (style) {
            case "Italic":
                return Font.ITALIC;
            case "Bold":
                return Font.BOLD;
            case "Bold Italic":
                return Font.BOLD | Font.ITALIC;
            default:
                return Font.PLAIN;
        }
    }

    public String getTextFieldValue(String textFieldName) {
        Component[] components = viewer.getFontDialog().getContentPane().getComponents();
        for (Component component : components) {
            if (component instanceof JTextField && textFieldName.equals(component.getName())) {
                return ((JTextField) component).getText();
            }
        }
        return "";
    }

    public void updateTextField(String textFieldName, String value) {
        Component[] components = viewer.getFontDialog().getContentPane().getComponents();
        for (Component component : components) {
            if (component instanceof JTextField && textFieldName.equals(component.getName())) {
                ((JTextField) component).setText(value);
                break;
            }
        }
    }
}