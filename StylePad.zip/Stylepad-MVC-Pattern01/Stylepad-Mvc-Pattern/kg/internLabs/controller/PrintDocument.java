package controller;

import viewer.Viewer;

import javax.swing.*;
import java.awt.*;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.util.ArrayList;
import java.util.List;

public class PrintDocument implements ActionController, Printable {
    private Viewer viewer;
    private String content;
    private Font fontOfField;
    private String[] textLines;
    private String[] contentSplit;
    private int[] pageBreaks;

    public PrintDocument(Viewer viewer) {
        this.viewer = viewer;
    }

    public PrintDocument(String content, Font fontOfField) {
        this.content = content;
        this.fontOfField = fontOfField;
    }

    @Override
    public void doAction() {
        viewer.showPrintDialog();
    }

    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
        // Set font from text area
        graphics.setFont(fontOfField);
        FontMetrics metrics = graphics.getFontMetrics(fontOfField);

        Graphics2D graphics2D = (Graphics2D) graphics;
        graphics2D.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

        // Height of font
        int lineHeight = metrics.getHeight();

        // Size of page
        int widthPage = (int) (pageFormat.getImageableWidth() - 100);
        System.out.println("Size of page: " + widthPage);
        splitContentText();

        List<String> containerList = new ArrayList<>();
        for (String word : contentSplit) {
            // Calculate width of line
            int widthLine = metrics.stringWidth(word);

            // If width of line less than width of page, then put it to containerList
            if (widthLine <= widthPage) {
                containerList.add(word);
            } else {
                String temp = "";
                int counter = 0;
                for (int i = 0; i < word.length(); i++) {
                    char symbol = word.charAt(i);
                    // Collecting line
                    temp = temp + symbol;
                    int lineWidth = metrics.stringWidth(temp);
                    if (!(lineWidth < widthPage)) {
                        int whiteSpace = temp.lastIndexOf(" ");
                        // if space didn't find do put it to containerList
                        if (whiteSpace == -1) {
                            containerList.add(temp);
                        } else {
                            counter = counter + whiteSpace;
                            i = counter;
                            containerList.add(temp.substring(0, whiteSpace));
                        }
                        temp = "";
                    }
                }
                containerList.add(temp);
            }
        }

        // Add formatted text to content
        content = String.join("\n", containerList);

        if (pageBreaks == null) {
            initTextLines();
            int linesPerPage = (int) ((pageFormat.getImageableHeight() - 50) / lineHeight);
            int numBreaks = (textLines.length - 1) / linesPerPage;
            pageBreaks = new int[numBreaks];
            for (int b = 0; b < numBreaks; b++) {
                pageBreaks[b] = (b + 1) * linesPerPage;
            }
        }

        if (pageIndex > pageBreaks.length) {
            return NO_SUCH_PAGE;
        }

        int x = 50;
        int y = 0;

        int start = (pageIndex == 0) ? 0 : pageBreaks[pageIndex - 1];
        int end = (pageIndex == pageBreaks.length) ? textLines.length : pageBreaks[pageIndex];
        for (int line = start; line < end; line++) {
            y = y + lineHeight;
            graphics.drawString(textLines[line], x, y);
        }

        // Print image
        if (pageIndex == pageBreaks.length) {
            ImageIcon imageIcon = new ImageIcon("resources/alice.gif");
            Image image = imageIcon.getImage();
            graphics.drawImage(image, x, y + lineHeight, null);
        }

        return PAGE_EXISTS;
    }

    private void initTextLines() {
        if (textLines == null) {
            textLines = content.split("\n");
        }
    }

    private void splitContentText() {
        if (contentSplit == null) {
            contentSplit = content.split("\n");
        }
    }
}
