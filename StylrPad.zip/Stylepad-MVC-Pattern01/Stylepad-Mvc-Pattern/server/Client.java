package server;
import javax.swing.text.Document;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.NotSerializableException;



public class Client implements Runnable {

    private final Socket socket;
    private Thread thread;

    public Client(Socket socket) {
        this.socket = socket;
        thread = new Thread(this);
    }

    public void run() {
        System.out.println("-----------------------------------------");
        try {
            Document document = readData();
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatForFileName = DateTimeFormatter.ofPattern("yyyyddMM_HHmmss");

            String formattedDate = "SPMVCP_" + formatForFileName.format(now) + ".spd";

            FileOutputStream fileOutputStream = new FileOutputStream(formattedDate);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(document);
            objectOutputStream.flush();

            socket.close();
        } catch (NotSerializableException nse) {
            System.out.println("Socket Error " + nse);
        } catch (IOException ioe) {
            System.out.println("Socket Error " + ioe);
        }
        System.out.println("-----------------------------------------");
    }

    public void go() {
        thread.start();
    }

    private Document readData() {
        try {
            InputStream input = socket.getInputStream();
            ObjectInputStream objectInputStream = new ObjectInputStream(input);
            Document dataFromClient = (Document)objectInputStream.readObject();

            return dataFromClient;
        } catch (IOException ioe) {
            System.out.println("Client Error: " + ioe);
            return null;
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Client Error ClassNotFound: " + cnfe);
            return null;
    }
    }
}
