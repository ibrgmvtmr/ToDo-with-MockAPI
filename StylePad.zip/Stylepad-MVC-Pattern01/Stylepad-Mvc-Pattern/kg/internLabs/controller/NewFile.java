package controller;

import javax.swing.text.DefaultStyledDocument;

import viewer.Viewer;

public class NewFile implements ActionController {

  private Viewer viewer;
  private MyDocumentListener documentListener;

  public NewFile(Viewer viewer) {
    this.viewer = viewer;
    documentListener = new MyDocumentListener(viewer);
  }

  public void doAction() {
    String contentInCurrentFile = viewer.getContent();

    if (!contentInCurrentFile.isEmpty()) {
      DefaultStyledDocument document = new DefaultStyledDocument();
      document.addDocumentListener(documentListener);

      boolean saveFile = viewer.suggestUserToSaveFile();

      if (saveFile) {
        viewer.clickSaveAs();
        viewer.update(document);
      } else {
        viewer.update(document);
      }
    }
  }

}
