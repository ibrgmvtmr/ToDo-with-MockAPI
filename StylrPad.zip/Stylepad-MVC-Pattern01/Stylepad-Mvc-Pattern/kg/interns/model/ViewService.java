package kg.interns.model;

import kg.interns.viewer.Viewer;
import kg.interns.controller.ActionController;


public class ViewService implements ActionController{

  private Viewer viewer;
  private String command;

  public ViewService(Viewer viewer, String command) {
    this.viewer = viewer;
    this.command = command;
  }

  public void doAction() {
    if (command.equals("ScaleIn")) {
      viewer.scaleIn();
    } else if (command.equals("ScaleOut")) {
      viewer.scaleOut();
    } else if (command.equals("DefaultScale")) {
      viewer.defaultScale();
    } else if (command.equals("OpenImage")) {
      viewer.insertImage();
    }
  }
}
