package controller;

import viewer.Viewer;

import java.io.File;
import javax.swing.text.Document;


public class SaveDocument implements  ActionController {

  private Viewer viewer;
  private File currentFile;


  public SaveDocument(Viewer viewer) {
      this.viewer = viewer;
      currentFile = viewer.getCurrentFile();
  }



  @Override
  public void doAction() {

    currentFile = viewer.getCurrentFile();

    if (currentFile != null) {
        SaveAsDocument saveAsDocument = new SaveAsDocument(viewer);
        Document content = viewer.getDocument();

        if (content != null) {
            saveAsDocument.saveToFile(currentFile, content);
        }
    } else {
        viewer.showNotFoundFile();
    }

  }

}
