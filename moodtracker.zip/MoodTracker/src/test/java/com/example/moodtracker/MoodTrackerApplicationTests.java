package com.example.moodtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoodTrackerApplicationTests {

    @Test
    void contextLoads() {
    }

}
