package kg.interns.model;

import javax.swing.text.DefaultStyledDocument;
import kg.interns.viewer.Viewer;
import kg.interns.listener.MyDocumentListener;
import kg.interns.controller.ActionController;

public class NewFile implements ActionController {

  private Viewer viewer;
  private MyDocumentListener documentListener;

  public NewFile(Viewer viewer) {
    this.viewer = viewer;
    documentListener = new MyDocumentListener(viewer);
  }

  public void doAction() {
    String contentInCurrentFile = viewer.getContent();

    if (contentInCurrentFile.isEmpty()) {
      return;
    }

    DefaultStyledDocument document = new DefaultStyledDocument();
    document.addDocumentListener(documentListener);

    boolean saveFile = viewer.suggestUserToSaveFile();

    if (saveFile) {
      viewer.clickSaveAs();
      viewer.update(document);
    } else {
      viewer.update(document);
    }

  }

}
