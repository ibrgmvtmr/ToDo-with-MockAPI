package kg.interns.model;

import java.io.File;
import javax.swing.text.Document;

import kg.interns.viewer.Viewer;
import kg.interns.controller.ActionController;



public class SaveDocument implements  ActionController {

  private Viewer viewer;
  private FileService fileService;


  public SaveDocument(Viewer viewer) {
      this.viewer = viewer;
      fileService = FileService.getInstance();
  }



  public void doAction() {

   File currentFile = fileService.getCurrentFile();

    if (currentFile != null) {
        SaveAsDocument saveAsDocument = new SaveAsDocument(viewer);
        Document content = viewer.getDocument();

        if (content != null) {
            saveAsDocument.saveToFile(currentFile, content);
        }
    } else {
        viewer.showNotFoundFile();
    }

  }

}
