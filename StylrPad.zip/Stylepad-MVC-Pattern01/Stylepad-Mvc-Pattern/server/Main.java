package server;

public class Main {
    public static void main(String[] args) {
        BackendForServer backendForServer = new BackendForServer(4042);
        backendForServer.startServer();
    }
}
