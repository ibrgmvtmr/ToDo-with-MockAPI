package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import viewer.ShowFrameAbout;
import viewer.StatusSpace;
import viewer.Viewer;

public class Controller implements ActionListener {

    private Viewer viewer;
    private Map<String, ActionController> map;

    public Controller(Viewer viewer) {
        this.viewer = viewer;
        initializeMap();
    }

    public void actionPerformed(ActionEvent event) {
        String actionCommand = event.getActionCommand();
        doAction(actionCommand);
        System.out.println(actionCommand);
    }

    public void doAction(String command) {
        if (map.containsKey(command)) {
            map.get(command).doAction();
        }
    }

    public void initializeMap() {
        if (map == null) {
            map = new HashMap<>();
        }

        // File menu
        initializeMap("Print", new PrintDocument(viewer));
        initializeMap("Open file", new OpenDocument(viewer));
        initializeMap("Save as", new SaveAsDocument(viewer));
        initializeMap("Save", new SaveDocument(viewer));
        initializeMap("New file", new NewFile(viewer));
        initializeMap("Exit", new ExitButton());
        initializeMap("OpenImage", new ViewService(viewer, "OpenImage"));


        // Edit menu
        initializeMap("Cut", new EditService(viewer, "Cut"));
        initializeMap("Copy", new EditService(viewer, "Copy"));
        initializeMap("Paste", new EditService(viewer, "Paste"));
        initializeMap("Find", new EditService(viewer, "Find"));
        initializeMap("Close_Find", new EditService(viewer, "Close_Find"));
        initializeMap("FindButton", new EditService(viewer, "FindButton"));
        initializeMap("Cancel_Find", new EditService(viewer, "Cancel_Find"));
        initializeMap("CloseReplace", new EditService(viewer, "CloseReplace"));
        initializeMap("Replace", new EditService(viewer, "Replace"));
        initializeMap("ReplaceFunc", new EditService(viewer, "ReplaceFunc"));
        initializeMap("Go", new EditService(viewer, "GoTo"));
        initializeMap("GoToButton", new EditService(viewer, "GoToButton"));
        initializeMap("CancelGoTo", new EditService(viewer, "CancelGoTo"));
        initializeMap("Marker all", new EditService(viewer,"Marker all"));
        initializeMap("Time_and_date", new EditService(viewer, "Time_and_date"));
        initializeMap("Clear", new EditService(viewer, "Clear"));
        initializeMap("Findmore", new EditService(viewer, "Findmore"));
        initializeMap("FindMoreButton", new EditService(viewer, "FindMoreButton"));
        initializeMap("CancelFindMore", new EditService(viewer, "CancelFindMore"));
        // Format menu
        initializeMap("Font", new EditService(viewer, "Font"));
        initializeMap("CloseDialog", new EditService(viewer, "CloseDialog"));

        // View menu
        initializeMap("Status_space", new StatusSpace(viewer));
        initializeMap("ScaleIn", new ViewService(viewer, "ScaleIn"));
        initializeMap("ScaleOut", new ViewService(viewer, "ScaleOut"));
        initializeMap("DefaultScale", new ViewService(viewer, "DefaultScale"));

        // Help menu
        initializeMap("About", new ShowFrameAbout(viewer, "About"));
        initializeMap("OK", new ShowFrameAbout(viewer, "OK"));


    }

    public boolean initializeMap(String command, ActionController actionController) {
        if (map != null) {
            // Add objects to map
            map.put(command, actionController);
            return true;
        }
        return false;
    }
}
