package controller;

import viewer.Viewer;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.StyledDocument;

public class MyDocumentListener implements DocumentListener {
    private Viewer viewer;

    public MyDocumentListener(Viewer viewer) {
        this.viewer = viewer;
    }

    public void insertUpdate(DocumentEvent e) {
        updateStatus(); // For Find button
        updateSymbolLength(); // For amount of symbols and lines button
    }

    public void removeUpdate(DocumentEvent e) {
        updateStatus(); // For Find button
        updateSymbolLength();  // For amount of symbols and lines button
    }

    public void changedUpdate(DocumentEvent e) {
        updateStatus(); // For Find button
        updateSymbolLength(); // For amount of symbols and lines button
    }

    private void updateStatus() {
        updateFindStatus();
    }

    // For Find button
    private void updateFindStatus() {
        Document document = viewer.getDocument();
        if (document.getLength() == 0) {
            viewer.disableFind();
        } else {
            viewer.enableFind();
        }
    }

    // For status bar
    public void updateSymbolLength() {
        StyledDocument styledDocument = viewer.getStyledDocument();
        int symbolCount = 0; // Counter for symbols
        int lineCount = 1;   // Counter for lines

        try {
            // Gets all text of field
            String text = styledDocument.getText(0, styledDocument.getLength());
            // Put lines to array
            String[] lines = text.split("\n");
            // Get length of lines
            lineCount = lines.length;

            if (lines.length > 0) {
                // Calculates the number of characters in the last line
                symbolCount = lines[lines.length - 1].length();
            }
        } catch (BadLocationException ex) {
            ex.printStackTrace();
        }

        // Sends to update
        viewer.setAmountOfSymbols(symbolCount, lineCount);
    }
}
