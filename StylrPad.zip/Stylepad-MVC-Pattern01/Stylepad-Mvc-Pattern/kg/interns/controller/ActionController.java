package kg.interns.controller;

public interface ActionController {
    void doAction();
}
