package kg.interns.main;

import kg.interns.viewer.Viewer;

public class Main {
  public static void main(String[] args) {
        Viewer viewer = new Viewer();
    }
}
