package kg.interns.viewer;

import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.KeyStroke;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.JViewport;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.SpinnerNumberModel;
import javax.swing.SpinnerModel;
import javax.swing.BoxLayout;
import javax.swing.JSpinner;
import javax.swing.Icon;
import javax.swing.JMenuBar;
import javax.swing.JToolBar;
import javax.swing.JSeparator;
import javax.swing.BorderFactory;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JCheckBox;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Dimension;
import java.awt.Component;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;
import javax.swing.text.StyledDocument;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.StyleContext;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.text.Highlighter;
import javax.swing.text.DefaultHighlighter;


import kg.interns.controller.Controller;
import kg.interns.model.FileService;
import kg.interns.model.FontManager;
import kg.interns.model.SpaceManager;
import kg.interns.listener.MyDocumentListener;
import kg.interns.model.PrintDocument;


public class Viewer {

  private Map<String, Component> components;
  private Map<String, Integer> findComponent;

  public Viewer() {

    components = new HashMap<>();
    findComponent = new HashMap<>();
    findComponent.put("currentIndex", -1);
    findComponent.put("totalMatches", 0);
    findComponent.put("currentMatch", 0);

    JFrame frameAbout = new JFrame();
    components.put("frameAbout", frameAbout);

    JPanel statusBarPanel = createStatusBarPanel();
    components.put("statusBarPanel", statusBarPanel);

    Controller controller = new Controller(this);
    components.put("controller", controller);

    JFrame mainFrame = createMainFrame(getController());
    components.put("mainFrame", mainFrame);
  }

  public Controller getController() {
    return (Controller) components.get("controller");
  }

  public JFrame createMainFrame(Controller controller) {

    JMenuBar menuBar = createMenuBar(controller);
    JToolBar toolBar = createToolBar(controller);

    JPanel editorArea = createEditorArea();

    JPanel statusBar = (JPanel) components.get("statusBarPanel");
    editorArea.add("South", statusBar);

    ImageIcon icon = new ImageIcon("kg/interns/logo/notepad_icon_48.png");

    JFrame mainFrame = new JFrame();
    mainFrame.setSize(600, 600);
    mainFrame.setTitle("Command Design Pattern Stylepad MVC Pattern");
    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainFrame.add(toolBar, BorderLayout.NORTH);
    mainFrame.setIconImage(icon.getImage());
    mainFrame.add(editorArea);
    mainFrame.setJMenuBar(menuBar);
    mainFrame.setLocationRelativeTo(null);
    mainFrame.setVisible(true);
    components.put("mainFrame", mainFrame);

    return mainFrame;
  }

  private JMenuBar createMenuBar(Controller controller) {

    JMenu fileMenu = createFileMenu(controller);
    JMenu editMenu = createEditMenu(controller);
    JMenu formatMenu = createFormatMenu(controller);
    JMenu viewMenu = createViewMenu(controller);
    JMenu helpMenu = createHelpMenu(controller);

    JMenuBar menuBar = new JMenuBar();

    menuBar.add(fileMenu);
    menuBar.add(editMenu);
    menuBar.add(formatMenu);
    menuBar.add(viewMenu);
    menuBar.add(helpMenu);

    return menuBar;
  }

  private JMenu createFileMenu(Controller controller) {

    JMenuItem newFile = new JMenuItem("New file");
    newFile.setIcon(new ImageIcon("kg/interns/resources/new.png"));
    newFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
    newFile.addActionListener(controller);
    newFile.setActionCommand("New file");

    JMenuItem openFile = new JMenuItem("Open file");
    openFile.setIcon(new ImageIcon("kg/interns/resources/open.png"));
    openFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
    openFile.addActionListener(controller);
    openFile.setActionCommand("Open file");

    JMenuItem openImage = new JMenuItem("Open image");
    openImage.setIcon(new ImageIcon("kg/interns/resources/open.png"));
    openImage.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
    openImage.addActionListener(controller);
    openImage.setActionCommand("OpenImage");

    JMenuItem save = new JMenuItem("Save");
    save.setIcon(new ImageIcon("kg/interns/resources/save.png"));
    save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
    save.addActionListener(controller);
    save.setActionCommand("Save");

    JMenuItem saveToServer = new JMenuItem("Save to Server");
    saveToServer.setIcon(new ImageIcon("kg/interns/resources/server.png"));
    saveToServer.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));
    saveToServer.addActionListener(controller);
    saveToServer.setActionCommand("Save to Server");

    JMenuItem saveAs = new JMenuItem("Save as");
    saveAs.setIcon(new ImageIcon("kg/interns/resources/saveas.png"));
    saveAs.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK | ActionEvent.SHIFT_MASK));
    saveAs.addActionListener(controller);
    saveAs.setActionCommand("Save as");
    components.put("Save as", saveAs);

    JMenuItem print = new JMenuItem("Print...");
    print.setIcon(new ImageIcon("kg/interns/resources/print.png"));
    print.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
    print.addActionListener(controller);
    print.setActionCommand("Print");

    JMenuItem exit = new JMenuItem("Exit");
    exit.setIcon(new ImageIcon("kg/interns/resources/exit.png"));
    exit.addActionListener(controller);
    exit.setActionCommand("Exit");

    JMenu fileMenu = new JMenu("File");
    fileMenu.setMnemonic('F');

    fileMenu.add(newFile);
    fileMenu.add(openFile);
    fileMenu.add(openImage);
    fileMenu.addSeparator();
    fileMenu.add(save);
    fileMenu.add(saveToServer);
    fileMenu.add(saveAs);
    fileMenu.addSeparator();
    fileMenu.add(print);
    fileMenu.addSeparator();
    fileMenu.add(exit);

    return fileMenu;
  }

  public JMenu createEditMenu(Controller controller) {

    JMenuItem cut = new JMenuItem("Cut");
    cut.setIcon(new ImageIcon("kg/interns/resources/cut.png"));
    cut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
    cut.addActionListener(controller);
    cut.setActionCommand("Cut");

    JMenuItem copy = new JMenuItem("Copy");
    copy.setIcon(new ImageIcon("kg/interns/resources/copy.png"));
    copy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
    copy.addActionListener(controller);
    copy.setActionCommand("Copy");

    JMenuItem paste = new JMenuItem("Paste");
    paste.setIcon(new ImageIcon("kg/interns/resources/paste.png"));
    paste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, ActionEvent.CTRL_MASK));
    paste.addActionListener(controller);
    paste.setActionCommand("Paste");

    JMenuItem clear = new JMenuItem("Clear");
    clear.setIcon(new ImageIcon("kg/interns/resources/clear.png"));
    clear.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, ActionEvent.CTRL_MASK));
    clear.addActionListener(controller);
    clear.setActionCommand("Clear");

    JMenuItem find = new JMenuItem("Find");
    find.setIcon(new ImageIcon("kg/interns/resources/find.png"));
    find.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, ActionEvent.CTRL_MASK));
    find.addActionListener(controller);
    find.setActionCommand("Find");
    setFindMenuItem(find);
    find.setEnabled(false);

    JMenuItem findMore = new JMenuItem("Find more");
    findMore.setIcon(new ImageIcon("kg/interns/resources/findmore.png"));
    findMore.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, ActionEvent.SHIFT_MASK));
    findMore.addActionListener(controller);
    findMore.setActionCommand("Findmore");

    JMenuItem go = new JMenuItem("Go");
    go.setIcon(new ImageIcon("kg/interns/resources/go.png"));
    go.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G, ActionEvent.CTRL_MASK));
    go.addActionListener(controller);
    go.setActionCommand("Go");

    JMenuItem markerAll = new JMenuItem("Marker all");
    markerAll.setIcon(new ImageIcon("kg/interns/resources/markerall.png"));
    markerAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
    markerAll.addActionListener(controller);
    markerAll.setActionCommand("Marker all");

    JMenuItem replace = new JMenuItem("Replace");
    replace.setIcon(new ImageIcon("kg/interns/resources/replace2.png"));
    replace.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T, ActionEvent.CTRL_MASK | ActionEvent.SHIFT_MASK));
    replace.addActionListener(controller);
    replace.setActionCommand("Replace");

    JMenuItem timeAndDate = new JMenuItem("Time and date");
    timeAndDate.setIcon(new ImageIcon("kg/interns/resources/timeanddate.png"));
    timeAndDate.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T, ActionEvent.CTRL_MASK ));
    timeAndDate.addActionListener(controller);
    timeAndDate.setActionCommand("Time_and_date");

    JMenu editMenu = new JMenu("Edit");
    editMenu.setMnemonic('E');

    editMenu.add(copy);
    editMenu.add(cut);
    editMenu.add(paste);
    editMenu.add(clear);
    editMenu.addSeparator();
    editMenu.add(find);
    editMenu.add(findMore);
    editMenu.addSeparator();
    editMenu.add(go);
    editMenu.addSeparator();
    editMenu.add(markerAll);
    editMenu.add(replace);
    editMenu.add(timeAndDate);

    return editMenu;
  }

  public JMenu createFormatMenu(Controller controller) {

    JMenuItem wordSpace = new JMenuItem("Word Space");
    wordSpace.setIcon(new ImageIcon("kg/interns/resources/wordspace.png"));
    wordSpace.addActionListener(controller);
    wordSpace.setActionCommand("Word Space");

    JMenuItem font = new JMenuItem("Font");
    font.setIcon(new ImageIcon("kg/interns/resources/font.png"));
    font.addActionListener(controller);
    font.setActionCommand("Font");

    JMenu formatMenu = new JMenu("Format");
    formatMenu.setMnemonic('O');

    formatMenu.add(font);
    formatMenu.add(wordSpace);

    return formatMenu;
  }

  public JMenu createViewMenu(Controller controller) {

    JRadioButtonMenuItem statusSpace = new JRadioButtonMenuItem("Status space", false);
    statusSpace.setIcon(new ImageIcon("kg/interns/resources/statusspace.png"));
    statusSpace.addActionListener(controller);
    statusSpace.setActionCommand("Status_space");

    JMenu scaleJM = new JMenu("Scale");
    scaleJM.setIcon(new ImageIcon("kg/interns/resources/scale.png"));
    scaleJM.addActionListener(controller);
    scaleJM.setActionCommand("Scale");

    JMenuItem zoomInItem = new JMenuItem("Scale In");
    zoomInItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_EQUALS, ActionEvent.CTRL_MASK | ActionEvent.SHIFT_MASK));
    zoomInItem.setIcon(new ImageIcon("kg/interns/resources/sizeIn.png"));
    zoomInItem.addActionListener(controller);
    zoomInItem.setActionCommand("ScaleIn");

    JMenuItem zoomOutItem = new JMenuItem("Scale Out");
    zoomOutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_MINUS, ActionEvent.CTRL_MASK));
    zoomOutItem.setIcon(new ImageIcon("kg/interns/resources/sizeOut.png"));
    zoomOutItem.addActionListener(controller);
    zoomOutItem.setActionCommand("ScaleOut");

    JMenuItem defaultZoomItem = new JMenuItem("Restore Default Scale");
    defaultZoomItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_0, ActionEvent.CTRL_MASK));
    defaultZoomItem.setIcon(new ImageIcon("kg/interns/resources/restoreScale.png"));
    defaultZoomItem.addActionListener(controller);
    defaultZoomItem.setActionCommand("DefaultScale");

    scaleJM.add(zoomInItem);
    scaleJM.add(zoomOutItem);
    scaleJM.add(defaultZoomItem);

    JMenu viewMenu = new JMenu("View");
    viewMenu.setMnemonic('V');

    viewMenu.add(scaleJM);
    viewMenu.add(statusSpace);

    return viewMenu;
  }

  public JMenu createHelpMenu(Controller controller) {
    JMenuItem help = new JMenuItem("About");
    help.setIcon(new ImageIcon("kg/interns/resources/about.png"));
    help.addActionListener(controller);
    help.setActionCommand("About");

    JMenu helpMenu = new JMenu("About");
    helpMenu.setMnemonic('A');

    helpMenu.add(help);

    return helpMenu;
  }

  private JButton createToolButton(String iconPath, String tooltip) {
    ImageIcon icon = new ImageIcon(iconPath);
    JButton button = new JButton(icon);
    button.setToolTipText(tooltip);
    return button;
  }

  private JToolBar createToolBar(Controller controller) {

    JToolBar toolBar = new JToolBar();

    JButton newFileButton = createToolButton("kg/interns/resources/new_ToolBar.png", "New file");
    newFileButton.addActionListener(controller);
    newFileButton.setActionCommand("New file");
    toolBar.add(newFileButton);

    JButton openFileButton = createToolButton("kg/interns/resources/open_ToolBar.png", "Open file");
    openFileButton.addActionListener(controller);
    openFileButton.setActionCommand("Open file");
    toolBar.add(openFileButton);

    JButton saveFileButton = createToolButton("kg/interns/resources/save_ToolBar.png", "Save file");
    saveFileButton.addActionListener(controller);
    saveFileButton.setActionCommand("Save as");
    toolBar.add(saveFileButton);

    JButton cutButton = createToolButton("kg/interns/resources/cut_ToolBar.png", "Cut");
    cutButton.addActionListener(controller);
    cutButton.setActionCommand("Cut");
    toolBar.add(cutButton);

    JButton copyButton = createToolButton("kg/interns/resources/copy_ToolBar.png", "Copy");
    copyButton.addActionListener(controller);
    copyButton.setActionCommand("Copy");
    toolBar.add(copyButton);

    JButton pasteButton = createToolButton("kg/interns/resources/paste_ToolBar.png", "Paste");
    pasteButton.addActionListener(controller);
    pasteButton.setActionCommand("Paste");
    toolBar.add(pasteButton);

    return toolBar;
  }


  public void setFindMenuItem(JMenuItem menuItem) {
    components.put("menuItem", menuItem);
  }

  public JPanel createEditorArea() {

    JTextComponent editor = createEditor();
    Border raisedetched = BorderFactory.createEtchedBorder(EtchedBorder.RAISED);
    Border empty = new EmptyBorder(-2, -2, -2, -2);
    Border compound = BorderFactory.createCompoundBorder(empty, raisedetched);

    JScrollPane scrollPane = new JScrollPane();
    scrollPane.setBorder(compound);
    JViewport viewPort = scrollPane.getViewport();
    viewPort.add(editor);

    Color colorBackground = new Color(230, 230, 230);
    JPanel panel = new JPanel();
    panel.setBackground(colorBackground);
    panel.setLayout(new BorderLayout());
    panel.setBorder(compound);
    panel.add(scrollPane);

    return panel;
  }

  protected JTextComponent createEditor() {
    StyleContext sc = new StyleContext();
    DefaultStyledDocument doc = new DefaultStyledDocument(sc);
    JTextPane textPane = new JTextPane(doc);
    textPane.getDocument().addDocumentListener(new MyDocumentListener(this));
    textPane.setFont(new Font("Arial", Font.PLAIN, 20));

    components.put("textPane", textPane);

    return textPane;
  }

  public void showPrintDialog() {
    JTextPane textPane = (JTextPane) components.get("textPane");

    DefaultStyledDocument styledDocument = (DefaultStyledDocument) textPane.getDocument();
    Font fontOfField = textPane.getFont();

    PrintDocument printDocument = new PrintDocument(styledDocument, fontOfField);

    PrinterJob job = PrinterJob.getPrinterJob();
    job.setPrintable(printDocument);

    boolean doPrint = job.printDialog();
    if (doPrint) {
      try {
        job.print();
      } catch (PrinterException pe) {
        JOptionPane.showMessageDialog(null, pe);
      }
      JOptionPane.showMessageDialog(null, "Done Printing",
              "Information", JOptionPane.INFORMATION_MESSAGE);
    }
  }


  public Document getDocument() {
    JTextPane textPane = (JTextPane) components.get("textPane");
    return textPane.getDocument();
  }

  public String getContent() {
    JTextPane textPane = (JTextPane) components.get("textPane");
    return textPane.getText();
  }

  public StyledDocument getStyledDocument() {
    JTextPane textPane = (JTextPane) components.get("textPane");
    return textPane.getStyledDocument();
  }

  public File showSaveFileDialog() {
    JFileChooser fileChooser = (JFileChooser) components.get("fileChooser");

    if (fileChooser == null) {
      fileChooser = new JFileChooser();
      components.put("fileChooser", fileChooser);
    }
    File file = null;

    int returnVal = fileChooser.showSaveDialog(null);
    if (returnVal == JFileChooser.APPROVE_OPTION) {
      file = fileChooser.getSelectedFile();
    }

    return file;
  }

  public File showOpenFileDialog() {
    JFileChooser fileChooser = (JFileChooser) components.get("fileChooser");
    if (fileChooser == null) {
      fileChooser = new JFileChooser();
      components.put("fileChooser", fileChooser);
    }
    File file = null;

    int returnVal = fileChooser.showOpenDialog(null);
    if (returnVal == JFileChooser.APPROVE_OPTION) {
      file = fileChooser.getSelectedFile();
    }

    return file;
  }

  public void showNotFoundFile() {
    JOptionPane.showMessageDialog(null, "File not found.");
  }


  public void setContentOnTextArea(String fileContent) {
    JTextPane textPane = (JTextPane) components.get("textPane");
    textPane.setText(fileContent);
  }

  public void update(Document document) {
    JTextPane textPane = (JTextPane) components.get("textPane");

    if (textPane.getDocument() != null) {
      textPane.getDocument().removeUndoableEditListener(null);
      textPane.getDocument().removeDocumentListener(null);
    }
    document.addUndoableEditListener(null);
    document.addDocumentListener(new MyDocumentListener(this));
    textPane.setDocument(document);
  }

  public void updateOpen(String content) {
    JTextPane textPane = (JTextPane) components.get("textPane");
    textPane.setText(content);
  }

  public void showResultSaveDocumentIntoModel(boolean result) {
    if (result) {
      JOptionPane.showMessageDialog(null, "File saved successfully");
    } else {
      JOptionPane.showMessageDialog(null, "File didn't save", "ERROR", JOptionPane.ERROR_MESSAGE);
    }

  }

  public void cut() {
    JTextPane textPane = (JTextPane) components.get("textPane");
    textPane.cut();
  }

  public void paste() {
    JTextPane textPane = (JTextPane) components.get("textPane");
    textPane.paste();
  }

  public void copy() {
    JTextPane textPane = (JTextPane) components.get("textPane");
    textPane.copy();
  }

  public void scaleIn() {
    JTextPane textPane = (JTextPane) components.get("textPane");
    Font getFont = textPane.getFont();
    float getFontSize = getFont.getSize();
    float changeFontSize = getFontSize * 1.2F;

    Font newFont = new Font(getFont.getFontName(), getFont.getStyle(), (int) changeFontSize);

    textPane.setFont(newFont);
  }

  public void scaleOut() {
    JTextPane textPane = (JTextPane) components.get("textPane");
    Font getFont = textPane.getFont();
    float getFontSize = getFont.getSize();
    float changeFontSize = getFontSize / 1.2F;

    Font newFont = new Font(getFont.getFontName(), getFont.getStyle(), (int) changeFontSize);

    textPane.setFont(newFont);
  }

  public void defaultScale() {
    JTextPane textPane = (JTextPane) components.get("textPane");
    Font getFont = textPane.getFont();
    float getFontSize = getFont.getSize();
    float changeFontSize = 20.0F;

    Font newFont = new Font(getFont.getFontName(), getFont.getStyle(), (int) changeFontSize);

    textPane.setFont(newFont);
  }

  public void showFindDialog() {
    JFrame mainFrame = (JFrame) components.get("mainFrame");
    JDialog fontDialog = (JDialog) components.get("fontDialog");

    if (fontDialog == null) {
      fontDialog = new JDialog();
      fontDialog.setTitle("Find");
      fontDialog.setSize(400, 200);
      fontDialog.setModal(true);
      fontDialog.setResizable(false);

      JPanel panel = new JPanel();
      panel.setLayout(null);

      JTextField textField = new JTextField();
      textField.setBounds(90, 18, 185, 30);
      components.put("textField", textField);

      JButton findButton = new JButton("Find Next");
      findButton.setBounds(285, 17, 90, 34);
      findButton.addActionListener(getController());
      findButton.setActionCommand("FindButton");

      JButton cancelButton = new JButton("Cancel");
      cancelButton.addActionListener(getController());
      cancelButton.setActionCommand("Cancel_Find");
      cancelButton.setBounds(285, 50, 90, 34);

      JButton button = new JButton("Ok");
      button.addActionListener(getController());
      button.setActionCommand("CloseDialog");
      button.setBounds(300, 130, 80, 30);

      JLabel previewLabel = new JLabel("Ready to search");
      previewLabel.setFont(new Font("Arial", Font.PLAIN, 12));
      previewLabel.setBounds(20, 50, 254, 25);
      previewLabel.setBorder(BorderFactory.createEtchedBorder());
      components.put("previewLabel", previewLabel);

      JLabel textLabel = new JLabel("Find what: ");
      textLabel.setFont(new Font("Arial", Font.PLAIN, 15));
      textLabel.setBounds(20, 20, 100, 25);

      panel.add(textLabel);
      panel.add(textField);
      panel.add(button);
      panel.add(findButton);
      panel.add(cancelButton);
      panel.add(previewLabel);

      fontDialog.add(panel);
      components.put("fontDialog", fontDialog);
    }

    fontDialog.getRootPane().setDefaultButton((JButton) components.get("button"));
    fontDialog.setLocationRelativeTo(mainFrame);
    fontDialog.setVisible(true);
  }

  public void showFindMoreDialog() {
    JFrame mainFrame = (JFrame) components.get("mainFrame");
    JDialog fontDialog = (JDialog) components.get("fontDialog");

    if (fontDialog == null) {
      fontDialog = new JDialog();
      fontDialog.setTitle("Find More");
      fontDialog.setSize(400, 165);
      fontDialog.setModal(true);
      fontDialog.setResizable(false);
      components.put("fontDialog", fontDialog);

      JPanel panel = new JPanel();
      panel.setLayout(null);

      JTextField textField = new JTextField();
      textField.setBounds(90, 18, 185, 30);
      components.put("textField", textField);

      JLabel textLabel = new JLabel("Find what: ");
      textLabel.setFont(new Font("Arial", Font.PLAIN, 15));
      textLabel.setBounds(20, 20, 100, 25);

      JButton findButton = new JButton("Find");
      findButton.setBounds(285, 17, 90, 34);
      findButton.addActionListener(getController());
      findButton.setActionCommand("FindMoreButton");

      JButton cancelButton = new JButton("Cancel");
      cancelButton.addActionListener(getController());
      cancelButton.setActionCommand("CancelFindMore");
      cancelButton.setBounds(285, 50, 90, 34);

      JButton button = new JButton("Ok");
      button.addActionListener(getController());
      button.setActionCommand("CloseDialog");
      button.setBounds(300, 100, 80, 30);
      components.put("button", button);

      JCheckBox caseSensitiveBox = new JCheckBox("Case Sensitive");
      caseSensitiveBox.setBounds(20, 60, 150, 25);
      components.put("caseSensitiveBox", caseSensitiveBox);

      panel.add(textLabel);
      panel.add(textField);
      panel.add(findButton);
      panel.add(cancelButton);
      panel.add(caseSensitiveBox);
      panel.add(button);

      fontDialog.add(panel);
    }

    fontDialog.setLocationRelativeTo(mainFrame);
    fontDialog.setVisible(true);
  }


  public void closeDialog() {
    JDialog fontDialog = (JDialog) components.get("fontDialog");

    if (fontDialog != null) {
        fontDialog.dispose();
        components.put("fontDialog", null);
    }
  }

  public void findMore() {
    JDialog fontDialog = (JDialog) components.get("fontDialog");
    JTextField textField = (JTextField) components.get("textField");
    JTextPane textPane = (JTextPane) components.get("textPane");

    JCheckBox caseSensitiveBox = (JCheckBox) components.get("caseSensitiveBox");
    String textToFind = textField.getText();
    boolean caseSensitive = caseSensitiveBox.isSelected();
    String textContent = textPane.getText();

    if (textContent.isEmpty()) {
      JOptionPane.showMessageDialog(fontDialog, "Текстовая панель пустая. Нечего искать.");
    }
    if (!textToFind.isEmpty()) {
      highlightAllOccurrences(textToFind, caseSensitive);
    } else {
      JOptionPane.showMessageDialog(fontDialog, "Введите текст для поиска.");
    }
  }

  public void removeHighlightAll() {
    JTextPane textPane = (JTextPane)components.get("textPane");
    Highlighter highlighter = textPane.getHighlighter();
    highlighter.removeAllHighlights();
  }

  private void highlightAllOccurrences(String textToFind, boolean caseSensitive) {
    JTextPane textPane = (JTextPane)components.get("textPane");
    Highlighter highlighter = textPane.getHighlighter();
    highlighter.removeAllHighlights();

    String textContent = textPane.getText();
    int index;

    String searchContent = caseSensitive ? textContent : textContent.toLowerCase();
    String searchText = caseSensitive ? textToFind : textToFind.toLowerCase();

    index = searchContent.indexOf(searchText);
    while (index >= 0) {
      try {
        int end = index + textToFind.length();
        highlighter.addHighlight(index, end, new DefaultHighlighter.DefaultHighlightPainter(Color.LIGHT_GRAY));
        index = searchContent.indexOf(searchText, end);
      } catch (BadLocationException e) {
        e.printStackTrace();
      }
    }
  }

  public void findText() {
    JLabel previewLabel = (JLabel) components.get("previewLabel");
    JTextPane textPane = (JTextPane)components.get("textPane");
    JTextField textField = (JTextField) components.get("textField");

    String text = textField.getText().trim();

    if (!text.isEmpty()) {
      String documentText = textPane.getText();
      if (findComponent.get("currentIndex") == -1) {
          int totalMatches = countOccurrences(documentText, text);
          findComponent.put("totalMatches", totalMatches);
        if (totalMatches == 0) {
          previewLabel.setText("No matches found!");
          return;
        }
      }

      int index = documentText.indexOf(text, findComponent.get("currentIndex") + 1);
      if (index != -1) {
        findComponent.put("currentIndex", index);
        findComponent.put("currentMatch", findComponent.get("currentMatch") + 1);
        textPane.select(index, index + text.length());
        previewLabel.setText(String.format("Match %d of %d",  findComponent.get("currentMatch"), findComponent.get("totalMatches")));
      } else {
        previewLabel.setText("Reached end of document.");
        resetSearchState();
      }
    } else {
      previewLabel.setText("Please enter text to find");
    }
  }

  private void resetSearchState() {
    findComponent.put("currentIndex", -1);
    findComponent.put("currentMatch", 0);
  }

  public int countOccurrences(String documentText, String searchText) {
    int count = 0;
    int index = 0;

    while ((index = documentText.indexOf(searchText, index)) != -1) {
      count = count + 1;
      index += searchText.length();
    }

    return count;
  }

  public void resetSearch() {
    JTextPane textPane = (JTextPane)components.get("textPane");
    JLabel previewLabel = (JLabel) components.get("previewLabel");
    JTextField textField = (JTextField) components.get("textField");

    previewLabel.setText("Ready to search");
    textField.setText("");
    textField.requestFocus();
    textPane.select(0, 0);
  }

  public void enableFind() {
    JMenuItem menuItem = (JMenuItem) components.get("menuItem");
    if (menuItem != null) {
      menuItem.setEnabled(true);
    }
  }

  public void disableFind() {
    JMenuItem menuItem = (JMenuItem) components.get("menuItem");
    if (menuItem != null) {
      menuItem.setEnabled(false);
    }
  }

  public void replace() {
    JFrame mainFrame = (JFrame)components.get("mainFrame");
    JDialog fontDialog = new JDialog();
    fontDialog.setTitle("Replace");
    fontDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    fontDialog.setLocation(mainFrame.getX() + 140, mainFrame.getY() + 140);
    fontDialog.setSize(290, 200);
    fontDialog.setLayout(new BoxLayout(fontDialog.getContentPane(), BoxLayout.Y_AXIS));
    components.put("fontDialog", fontDialog);

    JLabel labelFind = new JLabel("Find");
    JTextField textFind = new JTextField();

    JLabel labelReplace = new JLabel("Replace to: ");
    JTextField textReplace = new JTextField();

    JButton replaceButton = new JButton("Replace");
    replaceButton.addActionListener(getController());
    // replaceButton.setActionCommand("ReplaceFunc");

    JButton cancelButton = new JButton("Cancel");
    cancelButton.addActionListener(getController());
    cancelButton.setActionCommand("CloseDialog");
    cancelButton.setBounds(285, 50, 90, 34);


    replaceButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        String a = textFind.getText();
        String b = textReplace.getText();

        JTextPane textPane = (JTextPane)components.get("textPane");
        String newContent = textPane.getText().replaceAll("(?i)" + Pattern.quote(a), b);
        textPane.setText(newContent);
        fontDialog.dispose();
      }
    });

    fontDialog.add(labelFind);
    fontDialog.add(textFind);
    fontDialog.add(labelReplace);
    fontDialog.add(textReplace);
    fontDialog.add(replaceButton);
    fontDialog.add(cancelButton);

    fontDialog.setVisible(true);
  }


  public void showGoToDialog() {
    JFrame mainFrame = (JFrame) components.get("mainFrame");

    JDialog goToDialog = new JDialog(mainFrame, "Go to line", true);
    components.put("goToDialog", goToDialog);

    goToDialog.setSize(300, 150);
    goToDialog.setLayout(new BorderLayout());

    JPanel inputPanel = new JPanel();
    inputPanel.setLayout(new FlowLayout());

    JLabel label = new JLabel("Line number:");
    JTextField lineNumberField = new JTextField(10);
    inputPanel.add(label);
    inputPanel.add(lineNumberField);
    components.put("lineNumberField", lineNumberField);

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new FlowLayout());

    JButton goToButton = new JButton("Go to");
    goToButton.setActionCommand("GoToButton");
    goToButton.addActionListener(getController());

    JButton cancelButton = new JButton("Cancel");
    cancelButton.setActionCommand("CancelGoTo");
    cancelButton.addActionListener(getController());
    buttonPanel.add(goToButton);
    buttonPanel.add(cancelButton);

    goToDialog.add(inputPanel, BorderLayout.CENTER);
    goToDialog.add(buttonPanel, BorderLayout.SOUTH);
    goToDialog.setLocationRelativeTo(mainFrame);
    goToDialog.setVisible(true);

    components.put("goToDialog", goToDialog);
  }

  public void goToLine() {
    JTextPane textPane = (JTextPane)components.get("textPane");
    JTextField lineNumberField = (JTextField) components.get("lineNumberField");

    String input = lineNumberField.getText().trim();
    JDialog goToDialog = (JDialog) components.get("goToDialog");
    try {
      int lineNumber = Integer.parseInt(input);
      Element root = textPane.getDocument().getDefaultRootElement();
      if (lineNumber > 0 && lineNumber <= root.getElementCount()) {
        Element line = root.getElement(lineNumber - 1);
        int start = line.getStartOffset();
        textPane.setCaretPosition(start);
        textPane.requestFocus();
        goToDialog.dispose();
      } else {
        JOptionPane.showMessageDialog(goToDialog, "The line number is beyond the total number of lines.", "Error", JOptionPane.ERROR_MESSAGE);
      }
    } catch (NumberFormatException ex) {
      JOptionPane.showMessageDialog(goToDialog, "Please enter a valid line number.", "Error", JOptionPane.ERROR_MESSAGE);
    }
  }

  public void closeGoToDialog() {
    JDialog goToDialog = (JDialog) components.get("goToDialog");
    if (goToDialog != null) {
      goToDialog.dispose();
      components.put("goToDialog", null);
    }
  }

  public void markerAll() {
    JFrame mainFrame = (JFrame)components.get("mainFrame");

    JTextPane textPane = (JTextPane)components.get("textPane");
    String content = textPane.getText();
    if (content.isEmpty()) {
      JOptionPane.showMessageDialog(mainFrame, "Нет текста для выделения");
      return;
    }
    textPane.selectAll();
  }

  public void showFontDialog() {
    JFrame mainFrame = (JFrame) components.get("mainFrame");

    FontManager fontManager = new FontManager(this);

    String[] availableFonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
    Integer[] fontSizes = {8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72};

    JDialog fontDialog = new JDialog(mainFrame, "Choose Font");
    fontDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    fontDialog.setLocation(mainFrame.getX() + 140, mainFrame.getY() + 140);
    fontDialog.setSize(530, 530);
    fontDialog.setLayout(null);
    fontDialog.setResizable(false);
    components.put("fontDialog", fontDialog);

    JLabel fontLabel = new JLabel("Font:");
    fontLabel.setBounds(5, 10, 50, 15);

    JTextPane textPane = (JTextPane) components.get("textPane");
    String initialFont = textPane.getFont().getFontName();
    JTextField fontInputField = new JTextField(initialFont);
    fontInputField.setBounds(5, 27, 200, 30);
    fontInputField.setName("fontInputField");

    JList<String> fontList = new JList<>(availableFonts);
    fontList.setSelectedValue(initialFont, true);
    fontList.setName("FontList");
    fontList.addListSelectionListener(fontManager);

    JScrollPane fontListScroll = new JScrollPane(fontList);
    fontListScroll.setBounds(5, 57, 200, 150);

    JLabel styleLabel = new JLabel("Style:");
    styleLabel.setBounds(225, 10, 50, 15);

    String initialStyle = mapStyleToText(textPane.getFont().getStyle());
    JTextField styleInputField = new JTextField(initialStyle);
    styleInputField.setBounds(225, 27, 150, 30);
    styleInputField.setName("styleInputField");

    JList<String> styleList = new JList<>(new String[]{"Regular", "Italic", "Bold", "Bold Italic"});
    styleList.setSelectedValue(initialStyle, true);
    styleList.setName("StyleList");
    styleList.addListSelectionListener(fontManager);

    JScrollPane styleListScroll = new JScrollPane(styleList);
    styleListScroll.setBounds(225, 57, 150, 150);

    JLabel sizeLabel = new JLabel("Size:");
    sizeLabel.setBounds(395, 10, 50, 15);

    int initialSize = textPane.getFont().getSize();
    JTextField sizeInputField = new JTextField(String.valueOf(initialSize));
    sizeInputField.setBounds(395, 27, 70, 30);
    sizeInputField.setName("sizeInputField");

    JList<Integer> sizeList = new JList<>(fontSizes);
    sizeList.setSelectedValue(initialSize, true);
    sizeList.setName("SizeList");
    sizeList.addListSelectionListener(fontManager);

    JScrollPane sizeListScroll = new JScrollPane(sizeList);
    sizeListScroll.setBounds(395, 37, 70, 170);

    JLabel colorLabel = new JLabel("Color:");
    colorLabel.setBounds(5, 217, 50, 15);

    JPanel colorPanel = new JPanel(new GridLayout(0, 1));
    colorPanel.setBounds(5, 240, 200, 100);
    colorPanel.setName("ColorTextPanel");
    colorPanel.setBorder(BorderFactory.createTitledBorder(""));

    JRadioButton radioRed = new JRadioButton("Red");
    radioRed.setActionCommand("RedColor");
    radioRed.addActionListener(fontManager);

    JRadioButton radioBlue = new JRadioButton("Blue");
    radioBlue.setActionCommand("BlueColor");
    radioBlue.addActionListener(fontManager);

    JRadioButton radioGreen = new JRadioButton("Green");
    radioGreen.setActionCommand("GreenColor");
    radioGreen.addActionListener(fontManager);

    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(radioRed);
    buttonGroup.add(radioBlue);
    buttonGroup.add(radioGreen);

    colorPanel.add(radioRed);
    colorPanel.add(radioBlue);
    colorPanel.add(radioGreen);

    JPanel samplePanel = new JPanel();
    samplePanel.setBounds(225, 217, 240, 100);
    samplePanel.setLayout(new BorderLayout());
    samplePanel.setName("sampleTextPanel");
    samplePanel.setBorder(BorderFactory.createTitledBorder("Preview"));
    JLabel previewLabel = new JLabel("AaBbCc");
    previewLabel.setHorizontalAlignment(JLabel.CENTER);
    previewLabel.setFont(textPane.getFont());
    samplePanel.add(previewLabel);
    components.put("previewLabel", previewLabel);

    JButton applyButton = new JButton("Apply");
    applyButton.setBounds(250, 450, 100, 30);
    applyButton.setFocusable(false);
    applyButton.setActionCommand("ApplyFont");
    applyButton.addActionListener(fontManager);

    JButton cancelButton = new JButton("Cancel");
    cancelButton.setBounds(370, 450, 100, 30);
    cancelButton.setFocusable(false);
    cancelButton.setActionCommand("CloseDialog");
    cancelButton.addActionListener(fontManager); // Changed to fontManager for consistency

    fontDialog.add(applyButton);
    fontDialog.add(cancelButton);
    fontDialog.add(fontLabel);
    fontDialog.add(fontInputField);
    fontDialog.add(fontListScroll);
    fontDialog.add(styleLabel);
    fontDialog.add(styleListScroll);
    fontDialog.add(styleInputField);
    fontDialog.add(sizeLabel);
    fontDialog.add(sizeInputField);
    fontDialog.add(sizeListScroll);
    fontDialog.add(samplePanel);
    fontDialog.add(colorLabel);
    fontDialog.add(colorPanel);
    fontDialog.setVisible(true);

    fontManager.updateStyleList(initialFont);
  }


  public void showSpacetDialog(){
    JFrame mainFrame = (JFrame)components.get("mainFrame");

    JDialog fontDialog = new JDialog(mainFrame, "Space changer");
    fontDialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    fontDialog.setLocation(mainFrame.getX() + 140, mainFrame.getY() + 140);
    fontDialog.setSize(220, 150);
    fontDialog.setLayout(null);
    fontDialog.setResizable(false);
    components.put("fontDialog", fontDialog);

    SpinnerModel numbers = new SpinnerNumberModel(8, 1, 16, 1);
    JSpinner spinner = new JSpinner (numbers);

    JPanel contents = new JPanel();
    contents.setBounds(10, 10, 200, 50);
    contents.setLayout(new BorderLayout());
    contents.setName("Input space number");
    contents.setBorder(BorderFactory.createTitledBorder("Input space number"));
    contents.add(spinner);

    JButton applyButton = new JButton("Apply");
    applyButton.setBounds(10, 70, 100, 30);
    applyButton.setFocusable(false);
    applyButton.setActionCommand("ApplySpace");

    JButton cancelButton = new JButton("Cancel");
    cancelButton.setBounds(110, 70, 100, 30);
    cancelButton.setFocusable(false);
    cancelButton.setActionCommand("CloseDialog");
    cancelButton.addActionListener(getController());


    fontDialog.add(contents);
    fontDialog.add(applyButton);
    fontDialog.add(cancelButton);
    fontDialog.setVisible(true);

    SpaceManager spaceManager = new SpaceManager(this);
    applyButton.addActionListener(spaceManager);
  }

  private String mapStyleToText(int fontStyle) {
    return switch (fontStyle) {
      case Font.PLAIN -> "Regular";
      case Font.ITALIC -> "Italic";
      case Font.BOLD -> "Bold";
      default -> "Bold Italic";
    };
  }

  public JTextPane getCurrentContent() {
    return (JTextPane)components.get("textPane");
  }

  public JDialog getFontDialog() {
    return (JDialog) components.get("fontDialog");
  }

  public void hideFontDialog() {
    JDialog fontDialog = (JDialog) components.get("fontDialog");
    fontDialog.setVisible(false);
  }

  public void updateSampleLabelFont(Font font) {
    JLabel previewLabel = (JLabel) components.get("previewLabel");
    previewLabel.setFont(font);
  }

  public void updateSampleLabelColor(Color color) {
    JLabel previewLabel = (JLabel) components.get("previewLabel");
    previewLabel.setForeground(color);
  }

  public Color getSampleLabelColor() {
    JLabel previewLabel = (JLabel) components.get("previewLabel");
    return previewLabel.getForeground();
  }

  public void setNewFontForTextArea(Font font) {
    JTextPane textPane = (JTextPane)components.get("textPane");
    textPane.setFont(font);
  }

  public void setNewColorFontForTextArea(Color color) {
    JTextPane textPane = (JTextPane)components.get("textPane");
    textPane.setForeground(color);
  }

  public void showError(String errorMessage) {
    JFrame mainFrame = (JFrame)components.get("mainFrame");

    JOptionPane.showMessageDialog(
        mainFrame,
        errorMessage,
        "Error",
        JOptionPane.ERROR_MESSAGE
    );
  }

  public void insertCurrentDateTime() {
    JTextPane textPane = (JTextPane)components.get("textPane");

    LocalDateTime now = LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm dd.MM.yyyy");
    String formatted = now.format(formatter);
    int position = textPane.getCaretPosition();
    try {
      textPane.getDocument().insertString(position, formatted, null);
    } catch (BadLocationException ble) {
      System.out.println("Error inserting date and time: " + ble);
    }
  }

  public void clearTextArea() {
    JTextPane textPane = (JTextPane)components.get("textPane");
    textPane.setText("");
  }

  public void insertImage() {
    JTextPane textPane = (JTextPane)components.get("textPane");
    File file = showOpenFileDialog();
    if (file != null) {
      Icon icon = new ImageIcon(file.getAbsolutePath());
      textPane.insertIcon(icon);
    }
  }

  public JPanel createStatusBarPanel() {
    Font fontForLabels = new Font("Arial", Font.BOLD, 13);

    JLabel labelOfColumn = new JLabel("Column: 1,");
    labelOfColumn.setFont(fontForLabels);
    components.put("labelOfColumn", labelOfColumn);

    JLabel labelOfLines = new JLabel("Lines: 1 ");
    labelOfLines.setFont(fontForLabels);
    components.put("labelOfLines", labelOfLines);

    JLabel labelUTF = new JLabel(" UTF-8");
    labelUTF.setFont(fontForLabels);

    JLabel labelSeparator = new JLabel("|");
    labelSeparator.setFont(fontForLabels);

    JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    statusPanel.setBackground(new Color(229, 224, 224));
    statusPanel.setBorder(new BevelBorder(BevelBorder.LOWERED));
    statusPanel.setPreferredSize(new Dimension(600, 23));
    statusPanel.add(labelOfColumn);
    statusPanel.add(labelOfLines);
    statusPanel.add(labelSeparator);
    statusPanel.add(labelUTF);
    statusPanel.setOpaque(true);
    statusPanel.setVisible(false);
    components.put("statusBarPanel", statusPanel);

    return statusPanel;
  }

  public void showStatusSpace(boolean flag) {
    JPanel statusBarPanel = (JPanel) components.get("statusBarPanel");
    statusBarPanel.setVisible(flag);
  }

  public void setAmountOfSymbols(int column, int lines) {
    JLabel labelOfColumn = (JLabel) components.get("labelOfColumn");
    labelOfColumn.setText("Column: " + column + ",");

    JLabel labelOfLines = (JLabel) components.get("labelOfLines");
    labelOfLines.setText("Lines: " + lines + " ");

  }

  public void frameAbout(boolean show) {
    JFrame frameAbout = (JFrame) components.get("frameAbout");
    frameAbout.setTitle("Command Design Pattern Stylepad MVC About");

    Font font = new Font("Calibri", Font.PLAIN, 14);

    JPanel logoPanel = new JPanel();
    logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
    logoPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));

    JSeparator jSeparator = new JSeparator(JSeparator.HORIZONTAL);
    jSeparator.setForeground(Color.GRAY);
    jSeparator.setBounds(0, 0, 600, 1);
    jSeparator.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

    JLabel logoLabel = new JLabel(new ImageIcon("kg/interns/logo/Command Design Pattern Logo.png"));

    logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
    logoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
    logoPanel.add(logoLabel);
    logoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
    logoPanel.add(jSeparator, BorderLayout.LINE_START);
    logoPanel.add(Box.createRigidArea(new Dimension(0, 10)));

    JPanel textPanel = new JPanel();
    textPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

    textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
    JLabel text = new JLabel("This stylepad was created by Command Design Pattern.");
    JLabel text2 = new JLabel("Start of the project: 18.10.2024");
    JLabel team1 = new JLabel("Team: Manap Koshoev, Aidai Kydykbekova, Viktor Shishkin,");
    JLabel team2 = new JLabel("Gulkaiyr Toktomusheva, Daniil Kovalenko, Kirill Novikov,");
    JLabel team3 = new JLabel("Asman Nurmanbetov, Albert Gadiev.");

    text.setAlignmentX(Component.LEFT_ALIGNMENT);
    text2.setAlignmentX(Component.LEFT_ALIGNMENT);
    team1.setAlignmentX(Component.LEFT_ALIGNMENT);
    team2.setAlignmentX(Component.LEFT_ALIGNMENT);
    team3.setAlignmentX(Component.LEFT_ALIGNMENT);

    text.setFont(font);
    text2.setFont(font);
    team1.setFont(font);
    team2.setFont(font);
    team3.setFont(font);

    textPanel.add(text);
    textPanel.add(text2);
    textPanel.add(Box.createRigidArea(new Dimension(0, 10)));
    textPanel.add(team1);
    textPanel.add(team2);
    textPanel.add(team3);

    JPanel iconPanel = new JPanel();
    JLabel notepadIcon = new JLabel(new ImageIcon("kg/interns/logo/notepad_icon_48.png"));
    iconPanel.add(notepadIcon);

    JPanel buttonPanel = new JPanel();
    JButton okButton = new JButton("OK");
    okButton.addActionListener(getController());
    okButton.setActionCommand("OK");
    buttonPanel.add(okButton);


    frameAbout.setForeground(Color.WHITE);
    frameAbout.add(logoPanel, BorderLayout.NORTH);
    frameAbout.add(textPanel, BorderLayout.CENTER);
    frameAbout.add(iconPanel, BorderLayout.WEST);
    frameAbout.add(buttonPanel, BorderLayout.SOUTH);
    frameAbout.setResizable(false);
    frameAbout.setSize(600, 400);
    frameAbout.setLocation(470, 200);
    frameAbout.setVisible(show);
  }

  public boolean suggestUserToSaveFile() {
    JFrame mainFrame = (JFrame)components.get("mainFrame");

    String[] options = {"Save", "Not Save"};

    int answer = JOptionPane.showOptionDialog(mainFrame,
        "Would you like to save current Document?",
        "Suggest to save File",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE,
        null,
        options,
        options[0]);

    if (answer == JOptionPane.NO_OPTION) {
      return false;
    }

    return true;
  }

  public void clickSaveAs() {
    JMenuItem buttonSaveAs = (JMenuItem) components.get("Save as");
    buttonSaveAs.doClick();
  }
}
